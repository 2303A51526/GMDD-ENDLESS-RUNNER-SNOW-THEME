#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace SnowRunner3D.EditorTools
{
    [InitializeOnLoad]
    public static class SnowRunnerEditorBuilder
    {
        static SnowRunnerEditorBuilder()
        {
            EditorApplication.delayCall += OnScriptsReloaded;
        }

        private static void OnScriptsReloaded()
        {
            GameManager.PurgeBrokenAndStaleObjects();

            if (EditorApplication.isPlaying)
            {
                GameManager gm = SnowCompatibility.FindOne<GameManager>();
                if (gm == null)
                {
                    GameObject root = new GameObject("SnowRunner3D_GameSystem");
                    gm = root.AddComponent<GameManager>();
                }
                gm.BuildCompleteRuntimeScene();
                gm.StartGame();
                return;
            }

            if (!EditorApplication.isPlayingOrWillChangePlaymode)
            {
                PopulateSceneObjectsOnly();
                EditorApplication.isPlaying = true;
            }
        }

        public static void PopulateSceneObjectsOnly()
        {
            GameManager.PurgeBrokenAndStaleObjects();

            GameObject oldSys = GameObject.Find("SnowRunner3D_GameSystem");
            if (oldSys != null) Object.DestroyImmediate(oldSys);

            GameObject root = new GameObject("SnowRunner3D_GameSystem");
            GameManager gm = root.AddComponent<GameManager>();
            gm.BuildCompleteRuntimeScene();
        }

        [MenuItem("Tools/Snow Runner 3D/START & PLAY GAME NOW _F5", priority = 0)]
        public static void StartAndPlayGameNow()
        {
            if (EditorApplication.isPlaying)
            {
                GameManager.PurgeBrokenAndStaleObjects();
                GameManager gm = SnowCompatibility.FindOne<GameManager>();
                if (gm == null)
                {
                    GameObject root = new GameObject("SnowRunner3D_GameSystem");
                    gm = root.AddComponent<GameManager>();
                }
                gm.BuildCompleteRuntimeScene();
                gm.StartGame();
            }
            else
            {
                PopulateSceneObjectsOnly();
                EditorApplication.isPlaying = true;
            }
        }

        [MenuItem("Tools/Snow Runner 3D/Rebuild & Fix Current Scene", priority = 1)]
        public static void RebuildAndPlay()
        {
            StartAndPlayGameNow();
        }

        [MenuItem("Tools/Snow Runner 3D/Build & Save Playable Scene", priority = 2)]
        public static void BuildAndSavePlayableScene()
        {
            if (EditorApplication.isPlaying)
            {
                EditorApplication.isPlaying = false;
                return;
            }

            Scene newScene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            newScene.name = "MainSnowRunner";

            PopulateSceneObjectsOnly();

            string sceneFolder = "Assets/SnowRunner3D/Scenes";
            if (!AssetDatabase.IsValidFolder("Assets/SnowRunner3D"))
                AssetDatabase.CreateFolder("Assets", "SnowRunner3D");
            if (!AssetDatabase.IsValidFolder(sceneFolder))
                AssetDatabase.CreateFolder("Assets/SnowRunner3D", "Scenes");

            string scenePath = sceneFolder + "/MainSnowRunner.unity";
            EditorSceneManager.SaveScene(newScene, scenePath);
            AssetDatabase.Refresh();

            EditorApplication.isPlaying = true;
        }
    }
}
#endif
