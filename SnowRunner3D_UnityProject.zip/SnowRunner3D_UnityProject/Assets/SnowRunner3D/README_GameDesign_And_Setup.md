# FrostPeak Runner 3D — Unity 3D Snow Endless Runner Project

This package provides a complete, playable **3D Snow Endless Runner** in Unity (compatible with **Unity 2021 LTS, Unity 2022 LTS, and Unity 6**, across both **URP** and **Built-in Render Pipeline**).

## Quick Start (3 Ways to Open & Run)

### Option 1: Import the `.unitypackage` into Any Unity Project (Fastest)
1. Open any 3D Unity project.
2. Go to **Assets > Import Package > Custom Package...** and select `SnowRunner3D.unitypackage` (or drag and drop it into your Unity `Project` window), then click **Import**.
3. Simply press the **Play** button (the `[RuntimeInitializeOnLoadMethod]` bootstrapper automatically constructs the entire 3D snow world, player, camera, particles, and UI!), **OR** click **Tools > Snow Runner 3D > Build & Save Playable Scene** in the top menu bar to populate the Hierarchy and save `Assets/SnowRunner3D/Scenes/MainSnowRunner.unity`.

### Option 2: Open the Standalone Unity Project Folder (`SnowRunner3D_UnityProject.zip`)
1. Extract `SnowRunner3D_UnityProject.zip` to a folder on your computer.
2. Open **Unity Hub**, click **Add > Add project from disk**, and select the extracted folder.
3. Once Unity opens, click **Tools > Snow Runner 3D > Build & Save Playable Scene** (or press **Play** immediately).

### Option 3: Drop-In Single Script (`SnowRunner3D_AllInOne.cs`)
1. Copy `SnowRunner3D_AllInOne.cs` into any folder inside `Assets/` in your Unity project.
2. Press **Play** in Unity — the script automatically builds and runs the game with zero manual Inspector setup.

## Controls
- **Switch Lanes (Left / Center / Right):** `A` / `D` or `Left Arrow` / `Right Arrow` (or **Swipe Left / Right** with Mouse/Touch)
- **Jump Over Logs & Ramps:** `W` / `Up Arrow` / `Space` (or **Swipe Up**)
- **Slide / Crouch Under Timber Gates:** `S` / `Down Arrow` (or **Swipe Down**; also fast-slams to the ground if used mid-air!)
- **Pause / Resume:** `P` or `Esc`

## Included C# Architecture (`Assets/SnowRunner3D/Scripts/`)
| Script | Responsibility |
| :--- | :--- |
| `GameManager.cs` | State machine (`MainMenu`, `Playing`, `Paused`, `GameOver`), score & distance tracking, `PlayerPrefs` high score persistence, avalanche threat meter, and responsive HUD Canvas builder |
| `PlayerSnowController.cs` | 3-lane `CharacterController` physics, snowboard carving roll/yaw tilt, jump gravity curve, crouch/slide collider resizing, shield & magnet timers, and keyboard + touch swipe input |
| `EndlessTrackSpawner.cs` | Object-pooled 3D snow chunk generator (`10` distinct procedural biome patterns, pine forests, alpine banks, lane grooves) with zero garbage collection spikes |
| `WorldElements.cs` | `CollectibleItem` (Snow Coins, Frost Shield, Ice Magnet, Score Crystals with magnetic pull), `ObstacleHazard` (Pine Trees, Low Log Barriers, High Slide Gates, Glacier Ice Shards, Rolling Snowballs, Soft Snowdrifts), and `AvalancheChaser` |
| `SnowCameraFollow.cs` & `SnowEnvironmentController.cs` | Smooth damped 3D camera with speed FOV boost, collision camera shake, 1,200-particle blizzard emitter, and Alpine Day-to-Aurora-Dusk lighting cycle |
| `SnowCompatibility.cs` | Automatic URP (`Universal Render Pipeline/Lit`) vs. Built-In (`Standard`) shader material creator and Unity 2021–Unity 6 font loader |
