using UnityEngine;

namespace SnowRunner3D
{
    public class SnowCameraFollow : MonoBehaviour
    {
        public static SnowCameraFollow Instance { get; private set; }

        public Transform target;
        public Vector3 gameplayOffset = new Vector3(0f, 4.7f, -7.4f);
        public Vector3 lobbyOffset = new Vector3(1.3f, 1.6f, 3.2f);
        public float lateralFollowRatio = 0.65f;
        public float smoothSpeed = 11f;

        private Camera _cam;
        private float _shakeTimer;
        private float _shakeMagnitude;

        private void Awake()
        {
            Instance = this;
            _cam = GetComponent<Camera>();
        }

        public void TriggerShake(float duration, float magnitude)
        {
            _shakeTimer = duration;
            _shakeMagnitude = magnitude;
        }

        private void LateUpdate()
        {
            if (target == null) return;

            bool isLobby = GameManager.Instance != null && GameManager.Instance.State == GameState.Lobby;

            if (isLobby)
            {
                // Cinematic Showcase Camera in Lobby looking diagonally front at the rider
                Vector3 desiredLobbyPos = target.position + lobbyOffset;
                transform.position = Vector3.Lerp(transform.position, desiredLobbyPos, 8f * Time.deltaTime);
                Vector3 lookPoint = target.position + new Vector3(0f, 1.15f, 0f);
                transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(lookPoint - transform.position), 8f * Time.deltaTime);

                if (_cam != null)
                    _cam.fieldOfView = Mathf.Lerp(_cam.fieldOfView, 50f, 6f * Time.deltaTime);
                return;
            }

            // Gameplay 3rd person follow
            Vector3 desiredPos = new Vector3(
                target.position.x * lateralFollowRatio + gameplayOffset.x,
                gameplayOffset.y + Mathf.Max(0f, target.position.y * 0.35f),
                target.position.z + gameplayOffset.z
            );

            Vector3 smoothed = Vector3.Lerp(transform.position, desiredPos, smoothSpeed * Time.deltaTime);
            smoothed.z = desiredPos.z;

            if (_shakeTimer > 0f)
            {
                _shakeTimer -= Time.deltaTime;
                smoothed += Random.insideUnitSphere * _shakeMagnitude;
            }

            transform.position = smoothed;

            Vector3 lookPointGame = new Vector3(target.position.x * 0.45f, 1.35f + target.position.y * 0.25f, target.position.z + 11f);
            transform.rotation = Quaternion.Slerp(
                transform.rotation,
                Quaternion.LookRotation(lookPointGame - transform.position),
                12f * Time.deltaTime
            );

            if (_cam != null && GameManager.Instance != null && GameManager.Instance.Player != null)
            {
                float speedRatio = Mathf.InverseLerp(17f, 36f, GameManager.Instance.Player.CurrentSpeed);
                _cam.fieldOfView = Mathf.Lerp(_cam.fieldOfView, Mathf.Lerp(60f, 74f, speedRatio), 5f * Time.deltaTime);
            }
        }
    }

    public class SnowEnvironmentController : MonoBehaviour
    {
        public Transform followTarget;
        public Light directionalLight;

        private ParticleSystem _snowParticles;
        private Transform _horizonMountains;

        private void Start()
        {
            SetupAtmosphere();
        }

        public void SetupAtmosphere()
        {
            RenderSettings.fog = true;
            RenderSettings.fogMode = FogMode.Linear;
            RenderSettings.fogStartDistance = 42f;
            RenderSettings.fogEndDistance = 135f;
            RenderSettings.fogColor = new Color(0.80f, 0.90f, 0.99f);

            if (Camera.main != null)
            {
                Camera.main.clearFlags = CameraClearFlags.SolidColor;
                Camera.main.backgroundColor = new Color(0.72f, 0.86f, 0.98f);
            }

            if (_snowParticles == null)
            {
                Transform existingPs = transform.Find("BlizzardSnowParticles");
                if (existingPs != null)
                    _snowParticles = existingPs.GetComponent<ParticleSystem>();
                else
                    CreateSnowfallParticleSystem();
            }

            if (_horizonMountains == null)
            {
                Transform existingMtn = transform.Find("DistantAlpinePeaks");
                if (existingMtn != null)
                    _horizonMountains = existingMtn;
                else
                    CreateHorizonMountains();
            }
        }

        private void CreateHorizonMountains()
        {
            GameObject mtnRoot = new GameObject("DistantAlpinePeaks");
            mtnRoot.transform.SetParent(transform);
            _horizonMountains = mtnRoot.transform;

            Material rockMat = SnowCompatibility.CreateMaterial("DistantMountainRock", new Color(0.55f, 0.68f, 0.84f), 0.2f, 0f);
            Material peakSnowMat = SnowCompatibility.CreateMaterial("DistantPeakSnow", new Color(0.95f, 0.98f, 1.0f), 0.3f, 0f);

            float[] xPositions = { -65f, -38f, -14f, 16f, 42f, 68f };
            float[] heights = { 34f, 46f, 28f, 38f, 48f, 32f };

            for (int i = 0; i < xPositions.Length; i++)
            {
                GameObject peak = GameObject.CreatePrimitive(PrimitiveType.Cube);
                DestroyImmediate(peak.GetComponent<Collider>());
                peak.transform.SetParent(mtnRoot.transform);
                peak.transform.localPosition = new Vector3(xPositions[i], heights[i] * 0.35f, 115f);
                peak.transform.localRotation = Quaternion.Euler(15f, 45f, 15f);
                peak.transform.localScale = new Vector3(heights[i], heights[i], heights[i]);
                peak.GetComponent<Renderer>().sharedMaterial = rockMat;

                GameObject cap = GameObject.CreatePrimitive(PrimitiveType.Cube);
                DestroyImmediate(cap.GetComponent<Collider>());
                cap.transform.SetParent(mtnRoot.transform);
                cap.transform.localPosition = new Vector3(xPositions[i], heights[i] * 0.62f, 114f);
                cap.transform.localRotation = Quaternion.Euler(15f, 45f, 15f);
                cap.transform.localScale = new Vector3(heights[i] * 0.55f, heights[i] * 0.55f, heights[i] * 0.55f);
                cap.GetComponent<Renderer>().sharedMaterial = peakSnowMat;
            }
        }

        private void CreateSnowfallParticleSystem()
        {
            GameObject psObj = new GameObject("BlizzardSnowParticles");
            psObj.transform.SetParent(transform);
            _snowParticles = psObj.AddComponent<ParticleSystem>();

            var main = _snowParticles.main;
            main.loop = true;
            main.startLifetime = 4.5f;
            main.startSpeed = new ParticleSystem.MinMaxCurve(3.5f, 7.0f);
            main.startSize = new ParticleSystem.MinMaxCurve(0.08f, 0.22f);
            main.maxParticles = 1400;
            main.simulationSpace = ParticleSystemSimulationSpace.World;

            var emission = _snowParticles.emission;
            emission.rateOverTime = 260f;

            var shape = _snowParticles.shape;
            shape.shapeType = ParticleSystemShapeType.Box;
            shape.scale = new Vector3(28f, 2f, 45f);

            var velocity = _snowParticles.velocityOverLifetime;
            velocity.enabled = true;
            velocity.x = new ParticleSystem.MinMaxCurve(-2.0f, 1.5f);
            velocity.y = new ParticleSystem.MinMaxCurve(-5.5f, -3.0f);
            velocity.z = new ParticleSystem.MinMaxCurve(-6.0f, -2.0f);

            ParticleSystemRenderer psRenderer = psObj.GetComponent<ParticleSystemRenderer>();
            Shader particleShader = Shader.Find("Particles/Standard Unlit");
            if (particleShader == null) particleShader = SnowCompatibility.GetLitShader();
            Material snowFlakeMat = new Material(particleShader);
            snowFlakeMat.color = Color.white;
            psRenderer.sharedMaterial = snowFlakeMat;
        }

        private void LateUpdate()
        {
            if (followTarget != null)
            {
                if (_snowParticles != null)
                    _snowParticles.transform.position = followTarget.position + new Vector3(0f, 14f, 18f);

                if (_horizonMountains != null)
                    _horizonMountains.position = new Vector3(0f, -4f, followTarget.position.z);
            }

            if (GameManager.Instance != null && GameManager.Instance.State == GameState.Playing)
            {
                float cycle = Mathf.PingPong(GameManager.Instance.DistanceTraveled * 0.0012f, 1f);
                Color daySky = new Color(0.72f, 0.86f, 0.98f);
                Color duskSky = new Color(0.16f, 0.22f, 0.42f);
                Color currentSky = Color.Lerp(daySky, duskSky, cycle);

                RenderSettings.fogColor = currentSky;
                if (Camera.main != null)
                    Camera.main.backgroundColor = currentSky;

                if (directionalLight != null)
                {
                    directionalLight.color = Color.Lerp(new Color(1f, 0.97f, 0.92f), new Color(0.55f, 0.78f, 1.0f), cycle);
                    directionalLight.intensity = Mathf.Lerp(1.15f, 0.78f, cycle);
                }
            }
        }
    }
}
