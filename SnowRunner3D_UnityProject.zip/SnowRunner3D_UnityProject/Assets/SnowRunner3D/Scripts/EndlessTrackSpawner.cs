using System.Collections.Generic;
using UnityEngine;

namespace SnowRunner3D
{
    /// <summary>
    /// Capstone Presentation Procedural Track Spawner (SegmentGenerator.cs - Slide 14):
    /// Spawns modular 3D snow segments matching the presentation slides:
    /// - Narrow winding snow trail flanked by low-poly icy rock cliffs and spiky snow pines
    /// - Right flank: Frozen glacial river with blue ice slabs and wooden rope suspension bridge
    /// - Track hazards: Fallen snow logs (leap over), ice boulders, snow crates, and radiant crystals
    /// - Collectibles: Star coins in lines/jump arcs, and radiant blue ice gems
    /// </summary>
    public class EndlessTrackSpawner : MonoBehaviour
    {
        public Transform playerTransform;
        public int activeChunkCount = 7;
        public float chunkLength = 40f;
        public float laneWidth = 3.0f;

        private readonly List<GameObject> _chunkPool = new List<GameObject>();
        private readonly Queue<GameObject> _activeChunks = new Queue<GameObject>();
        private float _nextSpawnZ = 0f;

        private Material _snowGroundMat;
        private Material _cliffRockMat;
        private Material _glacierRiverMat;
        private Material _pineBarkMat;
        private Material _pineFoliageMat;
        private Material _iceCrystalMat;
        private Material _goldCoinMat;
        private Material _crateWoodMat;
        private Material _shieldCyanMat;
        private Material _heartRedMat;
        private Material _snowdriftMat;

        private void Awake()
        {
            EnsureInitialized();
        }

        public void EnsureInitialized()
        {
            if (_snowGroundMat == null)
            {
                InitializeMaterials();
            }

            _chunkPool.RemoveAll(item => item == null);

            if (_chunkPool.Count == 0)
            {
                for (int i = transform.childCount - 1; i >= 0; i--)
                {
                    DestroyImmediate(transform.GetChild(i).gameObject);
                }
                _activeChunks.Clear();
                BuildChunkPool();
            }
        }

        private void InitializeMaterials()
        {
            _snowGroundMat = SnowCompatibility.CreateMaterial("SnowTrailMat", new Color(0.94f, 0.97f, 1.0f), 0.25f, 0.0f);
            _cliffRockMat = SnowCompatibility.CreateMaterial("CliffRockMat", new Color(0.68f, 0.74f, 0.82f), 0.35f, 0.05f);
            _glacierRiverMat = SnowCompatibility.CreateMaterial("GlacierRiverMat", new Color(0.35f, 0.82f, 0.98f), 0.92f, 0.15f, new Color(0.1f, 0.35f, 0.5f));
            _pineBarkMat = SnowCompatibility.CreateMaterial("LogPineBark", new Color(0.42f, 0.26f, 0.16f), 0.15f, 0.0f);
            _pineFoliageMat = SnowCompatibility.CreateMaterial("PineNeedlesMat", new Color(0.10f, 0.40f, 0.25f), 0.2f, 0.0f);
            _iceCrystalMat = SnowCompatibility.CreateMaterial("RadiantIceGem", new Color(0.20f, 0.85f, 1.0f), 0.90f, 0.2f, new Color(0.15f, 0.65f, 0.95f));
            _goldCoinMat = SnowCompatibility.CreateMaterial("StarGoldCoin", new Color(1.0f, 0.85f, 0.10f), 0.85f, 0.65f, new Color(0.4f, 0.3f, 0.02f));
            _crateWoodMat = SnowCompatibility.CreateMaterial("SnowCrateWood", new Color(0.55f, 0.38f, 0.22f), 0.2f, 0.0f);
            _shieldCyanMat = SnowCompatibility.CreateMaterial("FrostShieldOrb", new Color(0.15f, 0.95f, 1.0f), 0.9f, 0.2f, new Color(0.15f, 0.6f, 0.7f));
            _heartRedMat = SnowCompatibility.CreateMaterial("HeartHealOrbMat", new Color(1.0f, 0.22f, 0.32f), 0.85f, 0.2f, new Color(0.55f, 0.05f, 0.12f));
            _snowdriftMat = SnowCompatibility.CreateMaterial("SnowdriftSoft", new Color(0.90f, 0.95f, 1.0f), 0.3f, 0.0f);
        }

        private void BuildChunkPool()
        {
            for (int i = 0; i < 10; i++)
            {
                GameObject chunk = CreateChunkTemplate(i);
                chunk.SetActive(false);
                _chunkPool.Add(chunk);
            }
        }

        public void ResetTrack()
        {
            EnsureInitialized();

            while (_activeChunks.Count > 0)
            {
                GameObject c = _activeChunks.Dequeue();
                if (c != null) c.SetActive(false);
            }

            foreach (GameObject c in _chunkPool)
            {
                if (c != null) c.SetActive(false);
            }

            _nextSpawnZ = 0f;

            for (int i = 0; i < activeChunkCount; i++)
            {
                SpawnNextChunk(i == 0);
            }
        }

        private void Update()
        {
            if (GameManager.Instance == null || GameManager.Instance.State != GameState.Playing)
                return;

            if (playerTransform == null) return;

            if (playerTransform.position.z - 45f > (_nextSpawnZ - activeChunkCount * chunkLength))
            {
                RecycleOldestAndSpawnNew();
            }
        }

        private void RecycleOldestAndSpawnNew()
        {
            if (_activeChunks.Count > 0)
            {
                GameObject oldest = _activeChunks.Dequeue();
                if (oldest != null) oldest.SetActive(false);
            }
            SpawnNextChunk(false);
        }

        private void SpawnNextChunk(bool isSafeStartChunk)
        {
            EnsureInitialized();
            if (_chunkPool.Count == 0) return;

            GameObject candidate = null;
            if (isSafeStartChunk)
            {
                candidate = _chunkPool[0];
            }
            else if (_chunkPool.Count > 1)
            {
                int startIdx = Random.Range(1, _chunkPool.Count);
                for (int i = 0; i < _chunkPool.Count - 1; i++)
                {
                    int idx = 1 + ((startIdx + i) % (_chunkPool.Count - 1));
                    if (_chunkPool[idx] != null && !_chunkPool[idx].activeSelf)
                    {
                        candidate = _chunkPool[idx];
                        break;
                    }
                }
            }

            if (candidate == null) candidate = _chunkPool[0];

            candidate.transform.position = new Vector3(0f, 0f, _nextSpawnZ);
            ReactivateAllChildren(candidate.transform);
            candidate.SetActive(true);

            _activeChunks.Enqueue(candidate);
            _nextSpawnZ += chunkLength;
        }

        private void ReactivateAllChildren(Transform root)
        {
            for (int i = 0; i < root.childCount; i++)
            {
                Transform child = root.GetChild(i);
                child.gameObject.SetActive(true);
            }
        }

        private GameObject CreateChunkTemplate(int patternIndex)
        {
            GameObject chunk = new GameObject($"SnowSegment_{patternIndex}");
            chunk.transform.SetParent(transform);

            // 1. Central Snowy Running Trail
            GameObject floor = GameObject.CreatePrimitive(PrimitiveType.Cube);
            floor.name = "SnowTrailSurface";
            floor.transform.SetParent(chunk.transform);
            floor.transform.localPosition = new Vector3(0f, -0.5f, chunkLength * 0.5f);
            floor.transform.localScale = new Vector3(laneWidth * 3.6f, 1f, chunkLength);
            floor.GetComponent<Renderer>().sharedMaterial = _snowGroundMat;

            // 2. Left Flank: Low-Poly Snow-Capped Mountain Cliffs & Evergreens (Slide 2 & 3)
            CreateLeftMountainCliff(chunk.transform, patternIndex);

            // 3. Right Flank: Frozen Glacial River with Blue Ice Slabs & Rope Bridge (Slide 2, 3, 12)
            CreateRightGlacialRiver(chunk.transform, patternIndex);

            // Safe start chunk
            if (patternIndex == 0)
            {
                CreateCoinLine(chunk.transform, 0, 8f, 5, 2.0f);
                CreateGem(chunk.transform, new Vector3(0f, 1.1f, 22f));
                return chunk;
            }

            // 4. Staggered Hazards matching presentation (Fallen Snow Logs, Ice Boulders, Snow Crates)
            System.Random rng = new System.Random(patternIndex * 1337 + 42);
            float[] rowZPositions = { 8f, 18f, 28f, 36f };

            foreach (float zPos in rowZPositions)
            {
                int safeLane = rng.Next(0, 3);
                int coinType = rng.Next(0, 3);

                for (int lane = 0; lane < 3; lane++)
                {
                    float xPos = (lane - 1) * laneWidth;

                    if (lane == safeLane)
                    {
                        double roll = rng.NextDouble();
                        if (roll < 0.15)
                        {
                            // Blue Ice Gem (+5 Score!)
                            CreateGem(chunk.transform, new Vector3(xPos, 1.1f, zPos));
                        }
                        else if (roll < 0.28)
                        {
                            CollectibleType pType = (rng.Next(0, 2) == 0) ? CollectibleType.FrostShield : CollectibleType.HeartHealOrb;
                            CreatePowerup(chunk.transform, new Vector3(xPos, 1.0f, zPos), pType);
                        }
                        else if (roll < 0.85)
                        {
                            CreateCoinLine(chunk.transform, lane - 1, zPos - 2f, 3, 1.8f);
                        }
                        continue;
                    }

                    int obsRoll = rng.Next(0, 100);
                    if (obsRoll < 38)
                    {
                        // Fallen Snowy Hollow Log (Leap over with Spacebar! Slide 6 & 11)
                        CreateFallenSnowLog(chunk.transform, new Vector3(xPos, 0f, zPos));
                        if (coinType == 0)
                            CreateCoinJumpArc(chunk.transform, xPos, zPos);
                    }
                    else if (obsRoll < 65)
                    {
                        // Glacier Ice Boulder (Faceted dome ice rock! Slide 6)
                        CreateIceBoulder(chunk.transform, new Vector3(xPos, 0f, zPos));
                    }
                    else if (obsRoll < 85)
                    {
                        // Snow-Topped Wooden Cargo Crate (Slide 6)
                        CreateSnowCrate(chunk.transform, new Vector3(xPos, 0f, zPos));
                    }
                    else
                    {
                        // Soft Snowdrift mound (Slide 20)
                        CreateSnowdriftMound(chunk.transform, new Vector3(xPos, 0f, zPos));
                    }
                }
            }

            return chunk;
        }

        private void CreateLeftMountainCliff(Transform parent, int seed)
        {
            System.Random rng = new System.Random(seed * 773 + 11);
            float cliffX = -laneWidth * 2.5f;

            // Rocky Wall
            GameObject cliff = GameObject.CreatePrimitive(PrimitiveType.Cube);
            cliff.name = "LeftMountainCliff";
            DestroyImmediate(cliff.GetComponent<Collider>());
            cliff.transform.SetParent(parent);
            cliff.transform.localPosition = new Vector3(cliffX - 2.5f, 3.5f, chunkLength * 0.5f);
            cliff.transform.localScale = new Vector3(5.5f, 8f, chunkLength);
            cliff.GetComponent<Renderer>().sharedMaterial = _cliffRockMat;

            // Snow Ledges & Radiant Blue Ice Crystals along the path
            for (float z = 3f; z < chunkLength; z += 7f)
            {
                float xLedge = cliffX + (float)rng.NextDouble() * 0.5f;
                GameObject crystal = CreateRadiantIceCrystalMesh(parent, new Vector3(xLedge + 0.4f, 0.4f, z));
                crystal.name = "BorderIceCrystal";

                GameObject tree = BuildLowPolyPine(parent, new Vector3(cliffX - 1.8f - (float)rng.NextDouble() * 1.5f, 2.5f, z + 2.5f), 1.1f);
                tree.name = "CliffPineTree";
            }
        }

        private void CreateRightGlacialRiver(Transform parent, int seed)
        {
            System.Random rng = new System.Random(seed * 911 + 29);
            float riverX = laneWidth * 2.6f;

            // Frozen Ice River Bed (Slide 2 & 3)
            GameObject river = GameObject.CreatePrimitive(PrimitiveType.Cube);
            river.name = "GlacialIceRiver";
            DestroyImmediate(river.GetComponent<Collider>());
            river.transform.SetParent(parent);
            river.transform.localPosition = new Vector3(riverX + 2.5f, -0.65f, chunkLength * 0.5f);
            river.transform.localScale = new Vector3(5.5f, 0.8f, chunkLength);
            river.GetComponent<Renderer>().sharedMaterial = _glacierRiverMat;

            // River bank snow stones & glowing crystal clusters
            for (float z = 4f; z < chunkLength; z += 8f)
            {
                GameObject crystal = CreateRadiantIceCrystalMesh(parent, new Vector3(riverX - 0.4f, 0.4f, z));
                crystal.name = "RiverIceCrystal";

                GameObject tree = BuildLowPolyPine(parent, new Vector3(riverX + 5.2f + (float)rng.NextDouble() * 1.2f, 0.4f, z + 3f), 0.95f);
                tree.name = "RiverPineTree";
            }

            // Rustic Wooden Suspension Rope Bridge crossing the river (Slide 3)
            if (seed % 2 == 0)
            {
                GameObject bridge = new GameObject("RusticWoodenBridge");
                bridge.transform.SetParent(parent);
                bridge.transform.localPosition = new Vector3(riverX + 2.5f, 1.4f, 20f);

                GameObject plank = GameObject.CreatePrimitive(PrimitiveType.Cube);
                DestroyImmediate(plank.GetComponent<Collider>());
                plank.transform.SetParent(bridge.transform);
                plank.transform.localPosition = Vector3.zero;
                plank.transform.localScale = new Vector3(5.2f, 0.15f, 1.4f);
                plank.GetComponent<Renderer>().sharedMaterial = _crateWoodMat;
            }
        }

        private GameObject BuildLowPolyPine(Transform parent, Vector3 localPos, float scale)
        {
            GameObject root = new GameObject("CapstonePineTree");
            root.transform.SetParent(parent);
            root.transform.localPosition = localPos;
            root.transform.localScale = Vector3.one * scale;

            // Trunk
            GameObject trunk = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            DestroyImmediate(trunk.GetComponent<Collider>());
            trunk.transform.SetParent(root.transform);
            trunk.transform.localPosition = new Vector3(0f, 0.8f, 0f);
            trunk.transform.localScale = new Vector3(0.45f, 0.8f, 0.45f);
            trunk.GetComponent<Renderer>().sharedMaterial = _pineBarkMat;

            // Layered Cone Foliage with Snow Caps (Slide 2, 3, 5, 9)
            float[] heights = { 1.55f, 2.45f, 3.25f, 3.95f };
            float[] widths = { 2.1f, 1.65f, 1.2f, 0.75f };
            for (int i = 0; i < heights.Length; i++)
            {
                GameObject foliage = GameObject.CreatePrimitive(PrimitiveType.Cube);
                DestroyImmediate(foliage.GetComponent<Collider>());
                foliage.transform.SetParent(root.transform);
                foliage.transform.localPosition = new Vector3(0f, heights[i], 0f);
                foliage.transform.localRotation = Quaternion.Euler(0f, i * 28f, 0f);
                foliage.transform.localScale = new Vector3(widths[i], 0.65f, widths[i]);
                foliage.GetComponent<Renderer>().sharedMaterial = _pineFoliageMat;

                GameObject snowTop = GameObject.CreatePrimitive(PrimitiveType.Cube);
                DestroyImmediate(snowTop.GetComponent<Collider>());
                snowTop.transform.SetParent(root.transform);
                snowTop.transform.localPosition = new Vector3(0f, heights[i] + 0.32f, 0f);
                snowTop.transform.localRotation = Quaternion.Euler(0f, i * 28f + 12f, 0f);
                snowTop.transform.localScale = new Vector3(widths[i] * 0.90f, 0.14f, widths[i] * 0.90f);
                snowTop.GetComponent<Renderer>().sharedMaterial = _snowGroundMat;
            }

            return root;
        }

        private GameObject CreateRadiantIceCrystalMesh(Transform parent, Vector3 localPos)
        {
            GameObject root = new GameObject("RadiantBlueIceCluster");
            root.transform.SetParent(parent);
            root.transform.localPosition = localPos;

            for (int i = -1; i <= 1; i++)
            {
                GameObject shard = GameObject.CreatePrimitive(PrimitiveType.Cube);
                DestroyImmediate(shard.GetComponent<Collider>());
                shard.transform.SetParent(root.transform);
                shard.transform.localPosition = new Vector3(i * 0.35f, 0.85f + (i == 0 ? 0.4f : 0f), 0f);
                shard.transform.localRotation = Quaternion.Euler(i * 14f, i * 32f, i * -18f);
                shard.transform.localScale = new Vector3(0.48f, 1.6f + (i == 0 ? 0.6f : 0f), 0.48f);
                shard.GetComponent<Renderer>().sharedMaterial = _iceCrystalMat;
            }

            return root;
        }

        private void CreateFallenSnowLog(Transform parent, Vector3 localPos)
        {
            GameObject root = new GameObject("FallenSnowLog");
            root.transform.SetParent(parent);
            root.transform.localPosition = localPos;

            // Hollow log trunk (Slide 6 & 11)
            GameObject log = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            DestroyImmediate(log.GetComponent<Collider>());
            log.transform.SetParent(root.transform);
            log.transform.localPosition = new Vector3(0f, 0.50f, 0f);
            log.transform.localRotation = Quaternion.Euler(0f, 0f, 90f);
            log.transform.localScale = new Vector3(0.60f, 1.30f, 0.60f);
            log.GetComponent<Renderer>().sharedMaterial = _pineBarkMat;

            // Snow dusting cap on top of the log
            GameObject snowCap = GameObject.CreatePrimitive(PrimitiveType.Cube);
            DestroyImmediate(snowCap.GetComponent<Collider>());
            snowCap.transform.SetParent(root.transform);
            snowCap.transform.localPosition = new Vector3(0f, 0.82f, 0f);
            snowCap.transform.localScale = new Vector3(2.4f, 0.16f, 0.50f);
            snowCap.GetComponent<Renderer>().sharedMaterial = _snowGroundMat;

            // Side ice support barrier (matching Slide 11)
            GameObject sidePost = GameObject.CreatePrimitive(PrimitiveType.Cube);
            DestroyImmediate(sidePost.GetComponent<Collider>());
            sidePost.transform.SetParent(root.transform);
            sidePost.transform.localPosition = new Vector3(1.15f, 0.5f, 0f);
            sidePost.transform.localScale = new Vector3(0.25f, 1.0f, 0.3f);
            sidePost.GetComponent<Renderer>().sharedMaterial = _iceCrystalMat;

            BoxCollider col = root.AddComponent<BoxCollider>();
            col.isTrigger = true;
            col.center = new Vector3(0f, 0.45f, 0f);
            col.size = new Vector3(2.3f, 0.90f, 0.65f);
            root.AddComponent<ObstacleHazard>();
        }

        private void CreateIceBoulder(Transform parent, Vector3 localPos)
        {
            GameObject root = new GameObject("GlacierIceBoulder");
            root.transform.SetParent(parent);
            root.transform.localPosition = localPos;

            // Faceted dome ice boulder (Slide 6)
            GameObject dome = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            DestroyImmediate(dome.GetComponent<Collider>());
            dome.transform.SetParent(root.transform);
            dome.transform.localPosition = new Vector3(0f, 0.90f, 0f);
            dome.transform.localScale = new Vector3(1.75f, 1.85f, 1.75f);
            dome.GetComponent<Renderer>().sharedMaterial = _iceCrystalMat;

            GameObject snowTop = GameObject.CreatePrimitive(PrimitiveType.Cube);
            DestroyImmediate(snowTop.GetComponent<Collider>());
            snowTop.transform.SetParent(root.transform);
            snowTop.transform.localPosition = new Vector3(0f, 1.65f, 0f);
            snowTop.transform.localScale = new Vector3(1.25f, 0.25f, 1.25f);
            snowTop.GetComponent<Renderer>().sharedMaterial = _snowGroundMat;

            SphereCollider col = root.AddComponent<SphereCollider>();
            col.isTrigger = true;
            col.center = new Vector3(0f, 0.9f, 0f);
            col.radius = 0.9f;
            root.AddComponent<ObstacleHazard>();
        }

        private void CreateSnowCrate(Transform parent, Vector3 localPos)
        {
            GameObject root = new GameObject("SnowCrate");
            root.transform.SetParent(parent);
            root.transform.localPosition = localPos;

            // Wooden Crate (Slide 6)
            GameObject box = GameObject.CreatePrimitive(PrimitiveType.Cube);
            DestroyImmediate(box.GetComponent<Collider>());
            box.transform.SetParent(root.transform);
            box.transform.localPosition = new Vector3(0f, 0.75f, 0f);
            box.transform.localScale = new Vector3(1.5f, 1.5f, 1.5f);
            box.GetComponent<Renderer>().sharedMaterial = _crateWoodMat;

            // Padded thick snow cushion on top of the crate
            GameObject snowCushion = GameObject.CreatePrimitive(PrimitiveType.Cube);
            DestroyImmediate(snowCushion.GetComponent<Collider>());
            snowCushion.transform.SetParent(root.transform);
            snowCushion.transform.localPosition = new Vector3(0f, 1.55f, 0f);
            snowCushion.transform.localScale = new Vector3(1.65f, 0.35f, 1.65f);
            snowCushion.GetComponent<Renderer>().sharedMaterial = _snowGroundMat;

            BoxCollider col = root.AddComponent<BoxCollider>();
            col.isTrigger = true;
            col.center = new Vector3(0f, 0.85f, 0f);
            col.size = new Vector3(1.55f, 1.7f, 1.55f);
            root.AddComponent<ObstacleHazard>();
        }

        private void CreateSnowdriftMound(Transform parent, Vector3 localPos)
        {
            GameObject root = new GameObject("SoftSnowdrift");
            root.transform.SetParent(parent);
            root.transform.localPosition = localPos;

            GameObject mound = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            DestroyImmediate(mound.GetComponent<Collider>());
            mound.transform.SetParent(root.transform);
            mound.transform.localPosition = new Vector3(0f, 0.32f, 0f);
            mound.transform.localScale = new Vector3(2.2f, 0.90f, 1.6f);
            mound.GetComponent<Renderer>().sharedMaterial = _snowdriftMat;

            SphereCollider col = root.AddComponent<SphereCollider>();
            col.isTrigger = true;
            col.center = new Vector3(0f, 0.35f, 0f);
            col.radius = 0.75f;

            ObstacleHazard haz = root.AddComponent<ObstacleHazard>();
            haz.isStumbleSnowdrift = true;
        }

        private void CreateCoinLine(Transform parent, int laneOffset, float startZ, int count, float spacing)
        {
            float x = laneOffset * laneWidth;
            for (int i = 0; i < count; i++)
            {
                CreateCoin(parent, new Vector3(x, 0.95f, startZ + i * spacing));
            }
        }

        private void CreateCoinJumpArc(Transform parent, float xPos, float centerZ)
        {
            float[] zOffsets = { -3.0f, -1.5f, 0f, 1.5f, 3.0f };
            float[] yHeights = { 1.3f, 2.4f, 3.1f, 2.4f, 1.3f };
            for (int i = 0; i < zOffsets.Length; i++)
            {
                CreateCoin(parent, new Vector3(xPos, yHeights[i], centerZ + zOffsets[i]));
            }
        }

        private void CreateCoin(Transform parent, Vector3 localPos)
        {
            GameObject root = new GameObject("StarGoldCoin");
            root.transform.SetParent(parent);
            root.transform.localPosition = localPos;

            // 1. Spinning Coin Mesh Container
            GameObject meshContainer = new GameObject("CoinModel");
            meshContainer.transform.SetParent(root.transform);
            meshContainer.transform.localPosition = Vector3.zero;

            // Outer Beveled Golden Rim (Slide 2 & User Image)
            GameObject outerRim = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            DestroyImmediate(outerRim.GetComponent<Collider>());
            outerRim.name = "OuterBeveledRim";
            outerRim.transform.SetParent(meshContainer.transform);
            outerRim.transform.localPosition = Vector3.zero;
            outerRim.transform.localRotation = Quaternion.Euler(90f, 0f, 0f);
            outerRim.transform.localScale = new Vector3(0.80f, 0.09f, 0.80f);
            outerRim.GetComponent<Renderer>().sharedMaterial = _goldCoinMat;

            // Recessed Inner Golden Coin Face
            Material innerFaceMat = SnowCompatibility.CreateMaterial("InnerCoinFace", new Color(1.0f, 0.88f, 0.25f), 0.90f, 0.5f, new Color(0.45f, 0.32f, 0.05f));
            for (int side = -1; side <= 1; side += 2)
            {
                GameObject face = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
                DestroyImmediate(face.GetComponent<Collider>());
                face.name = side == 1 ? "FrontFace" : "BackFace";
                face.transform.SetParent(meshContainer.transform);
                face.transform.localPosition = new Vector3(0f, 0f, side * 0.046f);
                face.transform.localRotation = Quaternion.Euler(90f, 0f, 0f);
                face.transform.localScale = new Vector3(0.68f, 0.015f, 0.68f);
                face.GetComponent<Renderer>().sharedMaterial = innerFaceMat;

                // 3D 5-Pointed Star Emblem on Front and Back (matching user image!)
                Material starMat = SnowCompatibility.CreateMaterial("StarEmblemMat", new Color(1.0f, 0.95f, 0.55f), 0.95f, 0.7f, new Color(0.6f, 0.45f, 0.1f));
                for (int p = 0; p < 5; p++)
                {
                    float angle = p * 72f - 90f;
                    GameObject starPoint = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    DestroyImmediate(starPoint.GetComponent<Collider>());
                    starPoint.name = "StarPoint_" + p;
                    starPoint.transform.SetParent(meshContainer.transform);
                    starPoint.transform.localPosition = new Vector3(
                        Mathf.Cos(angle * Mathf.Deg2Rad) * 0.12f,
                        Mathf.Sin(angle * Mathf.Deg2Rad) * 0.12f,
                        side * 0.058f
                    );
                    starPoint.transform.localRotation = Quaternion.Euler(0f, 0f, angle + 45f);
                    starPoint.transform.localScale = new Vector3(0.16f, 0.16f, 0.022f);
                    starPoint.GetComponent<Renderer>().sharedMaterial = starMat;
                }
            }

            // 2. Realistic Soft Drop Shadow on Snow underneath each coin (matching user image!)
            Material shadowMat = SnowCompatibility.CreateMaterial("CoinSnowShadow", new Color(0.45f, 0.58f, 0.74f, 0.65f), 0.1f, 0f);
            GameObject shadow = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            DestroyImmediate(shadow.GetComponent<Collider>());
            shadow.name = "SnowDropShadow";
            shadow.transform.SetParent(root.transform);
            shadow.transform.localPosition = new Vector3(0f, -localPos.y + 0.02f, 0f);
            shadow.transform.localScale = new Vector3(0.72f, 0.005f, 0.72f);
            shadow.GetComponent<Renderer>().sharedMaterial = shadowMat;

            // 3. Trigger Collider & Rotating Collectible Component
            SphereCollider col = root.AddComponent<SphereCollider>();
            col.isTrigger = true;
            col.radius = 0.88f;

            CollectibleItem item = root.AddComponent<CollectibleItem>();
            item.type = CollectibleType.GoldCoin;
            item.scoreValue = 1;
        }

        private void CreateGem(Transform parent, Vector3 localPos)
        {
            GameObject gem = GameObject.CreatePrimitive(PrimitiveType.Cube);
            gem.name = "BlueIceGem";
            DestroyImmediate(gem.GetComponent<Collider>());
            gem.transform.SetParent(parent);
            gem.transform.localPosition = localPos;
            gem.transform.localRotation = Quaternion.Euler(45f, 45f, 45f);
            gem.transform.localScale = new Vector3(0.65f, 0.65f, 0.65f);
            gem.GetComponent<Renderer>().sharedMaterial = _iceCrystalMat;

            SphereCollider col = gem.AddComponent<SphereCollider>();
            col.isTrigger = true;
            col.radius = 0.95f;

            CollectibleItem item = gem.AddComponent<CollectibleItem>();
            item.type = CollectibleType.BlueIceCrystal;
            item.scoreValue = 5;
        }

        private void CreatePowerup(Transform parent, Vector3 localPos, CollectibleType type)
        {
            GameObject orb = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            orb.name = $"Powerup_{type}";
            DestroyImmediate(orb.GetComponent<Collider>());
            orb.transform.SetParent(parent);
            orb.transform.localPosition = localPos;
            orb.transform.localScale = new Vector3(0.85f, 0.85f, 0.85f);
            orb.GetComponent<Renderer>().sharedMaterial = (type == CollectibleType.FrostShield) ? _shieldCyanMat : _heartRedMat;

            SphereCollider col = orb.AddComponent<SphereCollider>();
            col.isTrigger = true;
            col.radius = 0.85f;

            CollectibleItem item = orb.AddComponent<CollectibleItem>();
            item.type = type;
        }
    }
}
