using System.Collections.Generic;
using UnityEngine;

namespace SnowRunner3D
{
    /// <summary>
    /// SR University Capstone Player Movement Controller with Parka Dress Changer (v17):
    /// - 4 Parka Dress Costumes with real-time 3D preview in the Lobby:
    ///   [1] Classic Alpine (Red Coat, Teal Panel, White Fur - Presentation Slide 5)
    ///   [2] Glacier Cyan (Ice Blue Coat, Navy Panel, White Fur)
    ///   [3] Pine Ranger (Evergreen Pine Coat, Amber Gold Panel, Tan Pants)
    ///   [4] Aurora Pink (Coral Pink Coat, Violet Purple Panel, Dark Pants)
    /// - 3-Lane Carving, Leap over Fallen Snowy Logs (Spacebar / W), Slide (S), 3 Hearts & Audio
    /// </summary>
    [RequireComponent(typeof(CharacterController))]
    public class PlayerSnowController : MonoBehaviour
    {
        [Header("Lane & Movement Settings")]
        public float laneWidth = 3.0f;
        public float laneSwitchSpeed = 16f;
        public float baseForwardSpeed = 16f;
        public float maxForwardSpeed = 34f;
        public float speedIncreasePerSecond = 0.20f;

        [Header("Jump Physics")]
        public float jumpForce = 12.5f;
        public float gravity = -29f;
        public float slideDuration = 0.70f;

        [Header("Visual Components")]
        public Transform visualRoot;
        public Transform leftLeg;
        public Transform rightLeg;
        public Transform leftArm;
        public Transform rightArm;
        public ParticleSystem snowStepParticles;
        public GameObject shieldVisual;
        public GameObject magnetVisual;

        // Dress Renderers
        public Renderer torsoRenderer;
        public Renderer stripeRenderer;
        public Renderer hoodRenderer;
        public List<Renderer> sleeveRenderers = new List<Renderer>();
        public List<Renderer> furTrimRenderers = new List<Renderer>();
        public List<Renderer> pantsRenderers = new List<Renderer>();
        public List<Renderer> bootRenderers = new List<Renderer>();
        public List<Renderer> mittenRenderers = new List<Renderer>();

        private CharacterController _controller;
        private int _currentLane = 1;
        private float _currentForwardSpeed;
        private float _verticalVelocity;
        private bool _isSliding;
        private float _slideTimer;
        private float _originalHeight = 1.7f;
        private Vector3 _originalCenter = new Vector3(0f, 0.85f, 0f);

        private bool _uiLeftPressed;
        private bool _uiRightPressed;
        private bool _uiJumpPressed;
        private bool _uiSlidePressed;
        private int _lastOnGuiKeyFrame = -1;

        private float _shieldTimer;
        private float _magnetTimer;
        private float _invincibleTimer;
        private int _currentOutfitIndex = 0;

        public float CurrentSpeed => _currentForwardSpeed;
        public bool HasShield => _shieldTimer > 0f;
        public bool HasMagnet => _magnetTimer > 0f;
        public float ShieldRemaining => Mathf.Max(0f, _shieldTimer);
        public float MagnetRemaining => Mathf.Max(0f, _magnetTimer);

        private void Awake()
        {
            EnsureReferences();
            ResetPlayer();
        }

        private void EnsureReferences()
        {
            if (_controller == null) _controller = GetComponent<CharacterController>();
            if (visualRoot == null)
            {
                Transform found = transform.Find("VisualModel");
                if (found != null) visualRoot = found;
            }
            if (visualRoot != null)
            {
                if (leftLeg == null) leftLeg = visualRoot.Find("LeftLeg");
                if (rightLeg == null) rightLeg = visualRoot.Find("RightLeg");
                if (leftArm == null) leftArm = visualRoot.Find("LeftArm");
                if (rightArm == null) rightArm = visualRoot.Find("RightArm");

                if (torsoRenderer == null)
                {
                    Transform t = visualRoot.Find("KidTorso");
                    if (t != null) torsoRenderer = t.GetComponent<Renderer>();
                }
                if (stripeRenderer == null && torsoRenderer != null)
                {
                    Transform st = torsoRenderer.transform.Find("TealStripe");
                    if (st != null) stripeRenderer = st.GetComponent<Renderer>();
                }
                if (hoodRenderer == null)
                {
                    Transform h = visualRoot.Find("ParkaHoodShell");
                    if (h != null) hoodRenderer = h.GetComponent<Renderer>();
                }
            }
            if (snowStepParticles == null)
            {
                Transform found = transform.Find("SnowFootstepsParticle");
                if (found != null) snowStepParticles = found.GetComponent<ParticleSystem>();
            }
            if (shieldVisual == null)
            {
                Transform found = transform.Find("ShieldAura");
                if (found != null) shieldVisual = found.gameObject;
            }
            if (magnetVisual == null)
            {
                Transform found = transform.Find("MagnetAura");
                if (found != null) magnetVisual = found.gameObject;
            }
        }

        public void ResetPlayer()
        {
            EnsureReferences();
            if (_controller != null) _controller.enabled = false;
            transform.position = new Vector3(0f, 0.05f, 0f);
            transform.rotation = Quaternion.identity;
            if (_controller != null) _controller.enabled = true;

            _currentLane = 1;
            _currentForwardSpeed = baseForwardSpeed;
            _verticalVelocity = 0f;
            _isSliding = false;
            _shieldTimer = 0f;
            _magnetTimer = 0f;
            _invincibleTimer = 1.0f;

            RestoreControllerBounds();
            if (visualRoot != null)
            {
                visualRoot.localScale = Vector3.one;
                visualRoot.localRotation = Quaternion.identity;
                visualRoot.gameObject.SetActive(true);
            }

            _currentOutfitIndex = PlayerPrefs.GetInt("SnowRunner3D_SelectedOutfit", 0);
            ActivateOutfit(_currentOutfitIndex, false);

            UpdatePowerupVisuals();
        }

        public void ActivateOutfit(int outfitIndex, bool save = true)
        {
            EnsureReferences();
            _currentOutfitIndex = Mathf.Clamp(outfitIndex, 0, 3);
            if (save)
            {
                PlayerPrefs.SetInt("SnowRunner3D_SelectedOutfit", _currentOutfitIndex);
                PlayerPrefs.Save();
            }

            Color coatColor = new Color(0.88f, 0.15f, 0.22f);
            Color stripeColor = new Color(0.0f, 0.75f, 0.65f);
            Color furColor = new Color(0.97f, 0.96f, 0.92f);
            Color pantsColor = new Color(0.12f, 0.15f, 0.24f);
            Color bootColor = new Color(0.18f, 0.20f, 0.26f);
            string dressName = "CLASSIC RED";

            if (_currentOutfitIndex == 1) // Glacier Cyan
            {
                coatColor = new Color(0.08f, 0.70f, 0.94f);
                stripeColor = new Color(0.05f, 0.15f, 0.28f);
                furColor = new Color(0.98f, 0.99f, 1.0f);
                pantsColor = new Color(0.10f, 0.14f, 0.20f);
                bootColor = new Color(0.12f, 0.35f, 0.48f);
                dressName = "GLACIER CYAN";
            }
            else if (_currentOutfitIndex == 2) // Pine Ranger
            {
                coatColor = new Color(0.09f, 0.47f, 0.27f);
                stripeColor = new Color(1.0f, 0.66f, 0.08f);
                furColor = new Color(0.96f, 0.94f, 0.88f);
                pantsColor = new Color(0.31f, 0.24f, 0.18f);
                bootColor = new Color(0.24f, 0.18f, 0.12f);
                dressName = "PINE RANGER";
            }
            else if (_currentOutfitIndex == 3) // Aurora Pink
            {
                coatColor = new Color(1.0f, 0.16f, 0.43f);
                stripeColor = new Color(0.47f, 0.16f, 0.79f);
                furColor = new Color(1.0f, 0.96f, 1.0f);
                pantsColor = new Color(0.07f, 0.09f, 0.15f);
                bootColor = new Color(0.32f, 0.12f, 0.48f);
                dressName = "AURORA PINK";
            }

            Material coatMat = SnowCompatibility.CreateMaterial("CoatMat_" + _currentOutfitIndex, coatColor, 0.35f, 0.0f);
            Material stripeMat = SnowCompatibility.CreateMaterial("StripeMat_" + _currentOutfitIndex, stripeColor, 0.40f, 0.0f);
            Material furMat = SnowCompatibility.CreateMaterial("FurMat_" + _currentOutfitIndex, furColor, 0.15f, 0.0f);
            Material pantsMat = SnowCompatibility.CreateMaterial("PantsMat_" + _currentOutfitIndex, pantsColor, 0.25f, 0.0f);
            Material bootMat = SnowCompatibility.CreateMaterial("BootMat_" + _currentOutfitIndex, bootColor, 0.35f, 0.0f);

            if (torsoRenderer != null) torsoRenderer.sharedMaterial = coatMat;
            if (stripeRenderer != null) stripeRenderer.sharedMaterial = stripeMat;
            if (hoodRenderer != null) hoodRenderer.sharedMaterial = coatMat;

            foreach (Renderer r in sleeveRenderers) if (r != null) r.sharedMaterial = coatMat;
            foreach (Renderer r in furTrimRenderers) if (r != null) r.sharedMaterial = furMat;
            foreach (Renderer r in pantsRenderers) if (r != null) r.sharedMaterial = pantsMat;
            foreach (Renderer r in bootRenderers) if (r != null) r.sharedMaterial = bootMat;
            foreach (Renderer r in mittenRenderers) if (r != null) r.sharedMaterial = pantsMat;

            GameManager.Instance?.ShowFloatingBanner("DRESS CHANGED: " + dressName + "!");
        }

        public void QueueMoveLeft() { _uiLeftPressed = true; }
        public void QueueMoveRight() { _uiRightPressed = true; }
        public void QueueJump() { _uiJumpPressed = true; }
        public void QueueSlide() { _uiSlidePressed = true; }

        private void OnGUI()
        {
            Event e = Event.current;
            if (e != null && e.type == EventType.KeyDown && Time.frameCount != _lastOnGuiKeyFrame)
            {
                switch (e.keyCode)
                {
                    case KeyCode.A:
                    case KeyCode.LeftArrow:
                        _uiLeftPressed = true;
                        _lastOnGuiKeyFrame = Time.frameCount;
                        break;
                    case KeyCode.D:
                    case KeyCode.RightArrow:
                        _uiRightPressed = true;
                        _lastOnGuiKeyFrame = Time.frameCount;
                        break;
                    case KeyCode.W:
                    case KeyCode.UpArrow:
                    case KeyCode.Space:
                        _uiJumpPressed = true;
                        _lastOnGuiKeyFrame = Time.frameCount;
                        break;
                    case KeyCode.S:
                    case KeyCode.DownArrow:
                        _uiSlidePressed = true;
                        _lastOnGuiKeyFrame = Time.frameCount;
                        break;
                    // Change Dress: 1, 2, 3, 4
                    case KeyCode.Alpha1: ActivateOutfit(0); _lastOnGuiKeyFrame = Time.frameCount; break;
                    case KeyCode.Alpha2: ActivateOutfit(1); _lastOnGuiKeyFrame = Time.frameCount; break;
                    case KeyCode.Alpha3: ActivateOutfit(2); _lastOnGuiKeyFrame = Time.frameCount; break;
                    case KeyCode.Alpha4: ActivateOutfit(3); _lastOnGuiKeyFrame = Time.frameCount; break;
                }
            }
        }

        private void Update()
        {
            EnsureReferences();

            // In Lobby: Idle waving pose (Presentation Slide 5)
            if (GameManager.Instance != null && GameManager.Instance.State == GameState.Lobby)
            {
                if (snowStepParticles != null)
                {
                    var em = snowStepParticles.emission;
                    em.enabled = false;
                }
                if (visualRoot != null)
                {
                    visualRoot.localRotation = Quaternion.Euler(0f, 20f, 0f);
                }
                if (rightArm != null)
                {
                    float wave = Mathf.Sin(Time.time * 6f) * 25f;
                    rightArm.localRotation = Quaternion.Euler(-135f + wave, 0f, 20f);
                }
                if (leftArm != null)
                {
                    leftArm.localRotation = Quaternion.Euler(15f, 0f, -15f);
                }
                if (leftLeg != null) leftLeg.localRotation = Quaternion.identity;
                if (rightLeg != null) rightLeg.localRotation = Quaternion.identity;
                return;
            }

            if (GameManager.Instance == null || GameManager.Instance.State != GameState.Playing)
                return;

            _currentForwardSpeed = Mathf.MoveTowards(_currentForwardSpeed, maxForwardSpeed, speedIncreasePerSecond * Time.deltaTime);

            HandleInput();

            if (_shieldTimer > 0f) _shieldTimer -= Time.deltaTime;
            if (_magnetTimer > 0f) _magnetTimer -= Time.deltaTime;
            if (_invincibleTimer > 0f) _invincibleTimer -= Time.deltaTime;
            UpdatePowerupVisuals();

            if (_isSliding)
            {
                _slideTimer -= Time.deltaTime;
                if (_slideTimer <= 0f) EndSlide();
            }

            float targetX = (_currentLane - 1) * laneWidth;
            float newX = Mathf.Lerp(transform.position.x, targetX, laneSwitchSpeed * Time.deltaTime);
            float deltaX = newX - transform.position.x;

            if (_controller.isGrounded && _verticalVelocity < 0f)
                _verticalVelocity = -2f;
            else
                _verticalVelocity += gravity * Time.deltaTime;

            Vector3 moveVector = new Vector3(
                deltaX / Mathf.Max(Time.deltaTime, 0.0001f),
                _verticalVelocity,
                _currentForwardSpeed
            );
            _controller.Move(moveVector * Time.deltaTime);

            if (snowStepParticles != null)
            {
                var em = snowStepParticles.emission;
                em.enabled = _controller.isGrounded && !_isSliding;
            }

            // Running leg & arm swing animation cycle
            if (_controller.isGrounded && !_isSliding)
            {
                float runCycle = Mathf.Sin(Time.time * 18f);
                if (leftLeg != null) leftLeg.localRotation = Quaternion.Euler(runCycle * 38f, 0f, 0f);
                if (rightLeg != null) rightLeg.localRotation = Quaternion.Euler(-runCycle * 38f, 0f, 0f);
                if (leftArm != null) leftArm.localRotation = Quaternion.Euler(-runCycle * 34f, 0f, -12f);
                if (rightArm != null) rightArm.localRotation = Quaternion.Euler(runCycle * 34f, 0f, 12f);
            }
            else if (!_controller.isGrounded)
            {
                // Leap pose over fallen snowy log (Slide 11)
                if (leftLeg != null) leftLeg.localRotation = Quaternion.Euler(-32f, 0f, 0f);
                if (rightLeg != null) rightLeg.localRotation = Quaternion.Euler(42f, 0f, 0f);
                if (leftArm != null) leftArm.localRotation = Quaternion.Euler(-55f, 0f, -30f);
                if (rightArm != null) rightArm.localRotation = Quaternion.Euler(-55f, 0f, 30f);
            }

            if (visualRoot != null)
            {
                float lateralOffset = targetX - transform.position.x;
                float targetRoll = Mathf.Clamp(-lateralOffset * 8f, -18f, 18f);
                visualRoot.localRotation = Quaternion.Euler(0f, 0f, targetRoll);

                if (_invincibleTimer > 0f)
                {
                    bool flashVisible = Mathf.FloorToInt(_invincibleTimer * 14f) % 2 == 0;
                    visualRoot.gameObject.SetActive(flashVisible);
                }
                else if (!visualRoot.gameObject.activeSelf)
                {
                    visualRoot.gameObject.SetActive(true);
                }
            }
        }

        private void HandleInput()
        {
            bool moveLeft = _uiLeftPressed
                || SnowCompatibility.GetKeyDownSafe(KeyCode.A, "aKey")
                || SnowCompatibility.GetKeyDownSafe(KeyCode.LeftArrow, "leftArrowKey");

            bool moveRight = _uiRightPressed
                || SnowCompatibility.GetKeyDownSafe(KeyCode.D, "dKey")
                || SnowCompatibility.GetKeyDownSafe(KeyCode.RightArrow, "rightArrowKey");

            bool jump = _uiJumpPressed
                || SnowCompatibility.GetKeyDownSafe(KeyCode.W, "wKey")
                || SnowCompatibility.GetKeyDownSafe(KeyCode.UpArrow, "upArrowKey")
                || SnowCompatibility.GetKeyDownSafe(KeyCode.Space, "spaceKey");

            bool slide = _uiSlidePressed
                || SnowCompatibility.GetKeyDownSafe(KeyCode.S, "sKey")
                || SnowCompatibility.GetKeyDownSafe(KeyCode.DownArrow, "downArrowKey");

            _uiLeftPressed = false;
            _uiRightPressed = false;
            _uiJumpPressed = false;
            _uiSlidePressed = false;

            if (moveLeft && _currentLane > 0) _currentLane--;
            else if (moveRight && _currentLane < 2) _currentLane++;

            if (jump) TryJump();
            if (slide) TrySlide();
        }

        private void TryJump()
        {
            if (_controller != null && _controller.isGrounded)
            {
                if (_isSliding) EndSlide();
                _verticalVelocity = jumpForce;
                SnowCompatibility.PlayJumpSound();
            }
        }

        private void TrySlide()
        {
            if (_controller != null && !_controller.isGrounded)
                _verticalVelocity = -jumpForce * 1.4f;

            if (!_isSliding && _controller != null)
            {
                _isSliding = true;
                _slideTimer = slideDuration;
                _controller.height = _originalHeight * 0.45f;
                _controller.center = new Vector3(_originalCenter.x, _originalCenter.y * 0.45f, _originalCenter.z);
                if (visualRoot != null)
                    visualRoot.localScale = new Vector3(1.15f, 0.55f, 1.15f);
            }
        }

        private void EndSlide()
        {
            _isSliding = false;
            RestoreControllerBounds();
            if (visualRoot != null)
                visualRoot.localScale = Vector3.one;
        }

        private void RestoreControllerBounds()
        {
            if (_controller != null)
            {
                _controller.height = _originalHeight;
                _controller.center = _originalCenter;
            }
        }

        public void ActivateShield(float duration = 9f)
        {
            _shieldTimer = Mathf.Max(_shieldTimer, duration);
            UpdatePowerupVisuals();
        }

        public void ActivateMagnet(float duration = 11f)
        {
            _magnetTimer = Mathf.Max(_magnetTimer, duration);
            UpdatePowerupVisuals();
        }

        private void UpdatePowerupVisuals()
        {
            if (shieldVisual != null && shieldVisual.activeSelf != (_shieldTimer > 0f))
                shieldVisual.SetActive(_shieldTimer > 0f);

            if (magnetVisual != null && magnetVisual.activeSelf != (_magnetTimer > 0f))
                magnetVisual.SetActive(_magnetTimer > 0f);
        }

        public void HandleObstacleImpact(bool isStumbleHazard)
        {
            if (GameManager.Instance == null || GameManager.Instance.State != GameState.Playing)
                return;

            if (_invincibleTimer > 0f) return;

            if (_shieldTimer > 0f)
            {
                _shieldTimer = 0f;
                _invincibleTimer = 1.3f;
                UpdatePowerupVisuals();
                SnowCompatibility.PlayCrashSound();
                SnowCameraFollow.Instance?.TriggerShake(0.25f, 0.35f);
                GameManager.Instance?.ShowFloatingBanner("FROST SHIELD ABSORBED IMPACT!");
                return;
            }

            _invincibleTimer = 1.4f;
            SnowCompatibility.PlayCrashSound();
            SnowCameraFollow.Instance?.TriggerShake(0.35f, 0.50f);

            if (isStumbleHazard)
            {
                _currentForwardSpeed = Mathf.Max(baseForwardSpeed * 0.78f, _currentForwardSpeed - 4f);
                GameManager.Instance?.RegisterStumble();
            }
            else
            {
                _currentForwardSpeed = Mathf.Max(baseForwardSpeed * 0.80f, _currentForwardSpeed - 5f);
                GameManager.Instance?.TakePlayerDamage(1);
            }
        }
    }
}
