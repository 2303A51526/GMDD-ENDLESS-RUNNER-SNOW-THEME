using System;
using System.Reflection;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace SnowRunner3D
{
    /// <summary>
    /// SR University Capstone Project Helper:
    /// - Cross-pipeline compatibility (Universal Render Pipeline URP & Built-in Standard)
    /// - Procedural sound synthesizer for coin dings, gem chimes, jump whoosh, and snow crunch footsteps
    /// </summary>
    public static class SnowCompatibility
    {
        private static Shader _cachedLitShader;
        private static Font _cachedFont;
        private static AudioSource _sfxSource;

        private static AudioClip _clipCoin;
        private static AudioClip _clipGem;
        private static AudioClip _clipJump;
        private static AudioClip _clipCrash;

        public static T FindOne<T>() where T : UnityEngine.Object
        {
#if UNITY_2023_1_OR_NEWER
            return UnityEngine.Object.FindAnyObjectByType<T>();
#else
            return UnityEngine.Object.FindObjectOfType<T>();
#endif
        }

        public static Shader GetLitShader()
        {
            if (_cachedLitShader != null) return _cachedLitShader;

            if (GraphicsSettings.currentRenderPipeline != null)
            {
                _cachedLitShader = Shader.Find("Universal Render Pipeline/Lit");
                if (_cachedLitShader == null)
                    _cachedLitShader = Shader.Find("HDRP/Lit");
            }

            if (_cachedLitShader == null)
                _cachedLitShader = Shader.Find("Standard");

            if (_cachedLitShader == null)
                _cachedLitShader = Shader.Find("Legacy Shaders/Diffuse");

            return _cachedLitShader;
        }

        public static Material CreateMaterial(string name, Color color, float smoothness = 0.35f, float metallic = 0.0f, Color? emission = null)
        {
            Shader s = GetLitShader();
            Material mat = s != null ? new Material(s) : new Material(Shader.Find("Sprites/Default"));
            mat.name = name;

            if (mat.HasProperty("_Color")) mat.SetColor("_Color", color);
            if (mat.HasProperty("_Glossiness")) mat.SetFloat("_Glossiness", smoothness);
            if (mat.HasProperty("_Metallic")) mat.SetFloat("_Metallic", metallic);

            if (mat.HasProperty("_BaseColor")) mat.SetColor("_BaseColor", color);
            if (mat.HasProperty("_Smoothness")) mat.SetFloat("_Smoothness", smoothness);

            if (emission.HasValue)
            {
                mat.EnableKeyword("_EMISSION");
                if (mat.HasProperty("_EmissionColor"))
                    mat.SetColor("_EmissionColor", emission.Value);
            }

            return mat;
        }

        public static Font GetDefaultFont()
        {
            if (_cachedFont != null) return _cachedFont;

            _cachedFont = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            if (_cachedFont == null)
                _cachedFont = Resources.GetBuiltinResource<Font>("Arial.ttf");
            if (_cachedFont == null)
                _cachedFont = Font.CreateDynamicFontFromOSFont("Arial", 16);

            return _cachedFont;
        }

        private static void EnsureAudio()
        {
            if (!Application.isPlaying) return;

            if (_sfxSource == null)
            {
                GameObject audioObj = GameObject.Find("SnowRunner_AudioSynth");
                if (audioObj == null) audioObj = new GameObject("SnowRunner_AudioSynth");
                _sfxSource = audioObj.GetComponent<AudioSource>();
                if (_sfxSource == null) _sfxSource = audioObj.AddComponent<AudioSource>();
                _sfxSource.spatialBlend = 0f;
                _sfxSource.volume = 0.4f;
            }

            if (_clipCoin == null) _clipCoin = CreateToneClip("CoinSfx", 920f, 1380f, 0.12f, false);
            if (_clipGem == null) _clipGem = CreateToneClip("GemSfx", 1200f, 1850f, 0.18f, false);
            if (_clipJump == null) _clipJump = CreateToneClip("JumpSfx", 240f, 520f, 0.16f, false);
            if (_clipCrash == null) _clipCrash = CreateToneClip("CrashSfx", 280f, 80f, 0.25f, true);
        }

        private static AudioClip CreateToneClip(string name, float startFreq, float endFreq, float duration, bool addNoise)
        {
            int sampleRate = 22050;
            int sampleCount = Mathf.Max(1, Mathf.FloorToInt(sampleRate * duration));
            float[] data = new float[sampleCount];
            float phase = 0f;
            System.Random rng = new System.Random(name.GetHashCode());

            for (int i = 0; i < sampleCount; i++)
            {
                float t = (float)i / sampleCount;
                float freq = Mathf.Lerp(startFreq, endFreq, t);
                phase += (2f * Mathf.PI * freq) / sampleRate;
                float env = (1f - t) * (1f - t);
                float sample = Mathf.Sin(phase) * env;
                if (addNoise)
                {
                    sample = (sample * 0.45f) + (((float)rng.NextDouble() * 2f - 1f) * 0.55f * env);
                }
                data[i] = Mathf.Clamp(sample * 0.6f, -1f, 1f);
            }

            AudioClip clip = AudioClip.Create(name, sampleCount, 1, sampleRate, false);
            clip.SetData(data, 0);
            return clip;
        }

        public static void PlayCoinSound() { EnsureAudio(); if (_sfxSource != null && _clipCoin != null) _sfxSource.PlayOneShot(_clipCoin, 0.5f); }
        public static void PlayGemSound() { EnsureAudio(); if (_sfxSource != null && _clipGem != null) _sfxSource.PlayOneShot(_clipGem, 0.65f); }
        public static void PlayJumpSound() { EnsureAudio(); if (_sfxSource != null && _clipJump != null) _sfxSource.PlayOneShot(_clipJump, 0.55f); }
        public static void PlayCrashSound() { EnsureAudio(); if (_sfxSource != null && _clipCrash != null) _sfxSource.PlayOneShot(_clipCrash, 0.85f); }

        public static void SetupCompatibleEventSystem(GameObject eventSystemObj)
        {
            if (eventSystemObj.GetComponent<EventSystem>() == null)
                eventSystemObj.AddComponent<EventSystem>();

            Type newUiModuleType = Type.GetType("UnityEngine.InputSystem.UI.InputSystemUIInputModule, Unity.InputSystem");
            if (newUiModuleType != null)
            {
                StandaloneInputModule legacyMod = eventSystemObj.GetComponent<StandaloneInputModule>();
                if (legacyMod != null) UnityEngine.Object.DestroyImmediate(legacyMod);

                if (eventSystemObj.GetComponent(newUiModuleType) == null)
                    eventSystemObj.AddComponent(newUiModuleType);
            }
            else
            {
                if (eventSystemObj.GetComponent<StandaloneInputModule>() == null)
                    eventSystemObj.AddComponent<StandaloneInputModule>();
            }
        }

        public static bool GetKeyDownSafe(KeyCode legacyKey, string newInputKeyName)
        {
            try
            {
                if (Input.GetKeyDown(legacyKey)) return true;
            }
            catch
            {
            }

            return CheckNewInputSystemKey(newInputKeyName, true);
        }

        private static bool CheckNewInputSystemKey(string keyPropertyName, bool wasPressedThisFrame)
        {
            try
            {
                Type kbType = Type.GetType("UnityEngine.InputSystem.Keyboard, Unity.InputSystem");
                if (kbType == null) return false;

                PropertyInfo currentProp = kbType.GetProperty("current", BindingFlags.Public | BindingFlags.Static);
                object keyboard = currentProp?.GetValue(null);
                if (keyboard == null) return false;

                PropertyInfo keyProp = kbType.GetProperty(keyPropertyName, BindingFlags.Public | BindingFlags.Instance);
                object keyControl = keyProp?.GetValue(keyboard);
                if (keyControl == null) return false;

                PropertyInfo pressedProp = keyControl.GetType().GetProperty(
                    wasPressedThisFrame ? "wasPressedThisFrame" : "isPressed",
                    BindingFlags.Public | BindingFlags.Instance
                );
                if (pressedProp != null && pressedProp.GetValue(keyControl) is bool pressed)
                    return pressed;
            }
            catch
            {
            }
            return false;
        }
    }
}
