using UnityEngine;

namespace SnowRunner3D
{
    public enum CollectibleType
    {
        GoldCoin,
        BlueIceCrystal,
        FrostShield,
        HeartHealOrb
    }

    /// <summary>
    /// Capstone Presentation Collectibles (CollectCoin.cs & GemCollect.cs - Slide 21):
    /// - Gold Coins (Spinning gold coin with star in center, +1 count)
    /// - Blue Ice Crystals (Radiant glowing crystal gem, +5 count)
    /// - Includes shrink animation & magnetic attraction pull!
    /// </summary>
    public class CollectibleItem : MonoBehaviour
    {
        public CollectibleType type = CollectibleType.GoldCoin;
        public int scoreValue = 1;
        public float rotateSpeed = 130f;
        public float magnetPullRadius = 11f;
        public float magnetPullSpeed = 26f;

        private Vector3 _initialLocalPos;
        private bool _hasSavedPos;
        private bool _collected;

        private void Awake()
        {
            SaveInitialPos();
        }

        private void SaveInitialPos()
        {
            if (!_hasSavedPos)
            {
                _initialLocalPos = transform.localPosition;
                _hasSavedPos = true;
            }
        }

        private void OnEnable()
        {
            SaveInitialPos();
            _collected = false;
            transform.localPosition = _initialLocalPos;
            transform.localScale = Vector3.one;
        }

        private void Update()
        {
            if (GameManager.Instance == null || GameManager.Instance.State != GameState.Playing)
                return;

            transform.Rotate(Vector3.up, rotateSpeed * Time.deltaTime, Space.World);

            if ((type == CollectibleType.GoldCoin || type == CollectibleType.BlueIceCrystal)
                && GameManager.Instance.Player != null && GameManager.Instance.Player.HasMagnet)
            {
                Transform playerTransform = GameManager.Instance.Player.transform;
                float dist = Vector3.Distance(transform.position, playerTransform.position);
                if (dist <= magnetPullRadius)
                {
                    Vector3 target = playerTransform.position + Vector3.up * 0.85f;
                    transform.position = Vector3.MoveTowards(transform.position, target, magnetPullSpeed * Time.deltaTime);
                }
            }
        }

        private void OnTriggerEnter(Collider other)
        {
            if (_collected) return;
            if (GameManager.Instance == null || GameManager.Instance.State != GameState.Playing)
                return;

            PlayerSnowController player = other.GetComponent<PlayerSnowController>();
            if (player == null) player = other.GetComponentInParent<PlayerSnowController>();
            if (player == null) return;

            _collected = true;

            switch (type)
            {
                case CollectibleType.GoldCoin:
                    SnowCompatibility.PlayCoinSound();
                    GameManager.Instance.AddCoins(1, 10);
                    break;
                case CollectibleType.BlueIceCrystal:
                    SnowCompatibility.PlayGemSound();
                    GameManager.Instance.AddGems(1, 50);
                    break;
                case CollectibleType.FrostShield:
                    SnowCompatibility.PlayGemSound();
                    player.ActivateShield(9f);
                    GameManager.Instance?.ShowFloatingBanner("FROST SHIELD ACTIVE!");
                    break;
                case CollectibleType.HeartHealOrb:
                    SnowCompatibility.PlayCoinSound();
                    GameManager.Instance.HealPlayer(1);
                    GameManager.Instance?.ShowFloatingBanner("+1 HEART RESTORED!");
                    break;
            }

            gameObject.SetActive(false);
        }
    }

    /// <summary>
    /// Capstone Presentation Hazards (CollisionDetect.cs - Slide 6, 11, 20):
    /// - Fallen Snowy Log: Snow-covered hollow fallen tree trunk across the track (Leap over with Spacebar!)
    /// - Glacier Ice Boulder: Faceted icy rock formation blocking the trail (Steer around!)
    /// - Snow Crate: Wooden storage cargo crate with thick snow padding on top (Steer or jump!)
    /// - Soft Snowdrift: Piled snow mound (causes stumble & slowdown)
    /// </summary>
    public class ObstacleHazard : MonoBehaviour
    {
        public bool isStumbleSnowdrift = false;
        private Vector3 _initialLocalPos;
        private bool _hasSavedPos;

        private void Awake()
        {
            SaveInitialPos();
        }

        private void SaveInitialPos()
        {
            if (!_hasSavedPos)
            {
                _initialLocalPos = transform.localPosition;
                _hasSavedPos = true;
            }
        }

        private void OnEnable()
        {
            SaveInitialPos();
            transform.localPosition = _initialLocalPos;
        }

        private void OnTriggerEnter(Collider other)
        {
            if (GameManager.Instance == null || GameManager.Instance.State != GameState.Playing)
                return;

            PlayerSnowController player = other.GetComponent<PlayerSnowController>();
            if (player == null) player = other.GetComponentInParent<PlayerSnowController>();
            if (player == null) return;

            player.HandleObstacleImpact(isStumbleSnowdrift);
            gameObject.SetActive(false);
        }
    }

    public class AvalancheChaser : MonoBehaviour
    {
        public Transform playerTarget;
        public float safeFollowDistance = 12f;
        public float dangerFollowDistance = 4.0f;

        private float _currentOffset = 12f;

        private void Update()
        {
            if (playerTarget == null || GameManager.Instance == null) return;

            float threat = GameManager.Instance.AvalancheThreat;
            float targetDist = Mathf.Lerp(safeFollowDistance, dangerFollowDistance, threat);
            _currentOffset = Mathf.Lerp(_currentOffset, targetDist, 4f * Time.deltaTime);

            Vector3 pos = transform.position;
            pos.x = Mathf.Lerp(pos.x, playerTarget.position.x * 0.35f, 3f * Time.deltaTime);
            pos.y = 0f;
            pos.z = playerTarget.position.z - _currentOffset;
            transform.position = pos;
        }
    }
}
