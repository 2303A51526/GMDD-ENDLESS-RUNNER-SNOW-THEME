using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
#if UNITY_EDITOR
using UnityEditor;
#endif

namespace SnowRunner3D
{
    public enum GameState
    {
        Lobby,
        Playing,
        Paused,
        GameOver
    }

    /// <summary>
    /// SR University Capstone Game Manager (v17):
    /// - Interactive Lobby with Parka Dress Customizer:
    ///   [1] Classic Red, [2] Glacier Cyan, [3] Pine Ranger, [4] Aurora Pink
    /// - Live TextMeshPro/uGUI HUD: DISTANCE (m), COINS, and BLUE GEMS
    /// - SaveLoad: COINSAVE, GEMSAVE, DISTANCESAVE PlayerPrefs persistence
    /// </summary>
    public class GameManager : MonoBehaviour
    {
        public static GameManager Instance { get; private set; }

        public PlayerSnowController Player { get; private set; }
        public EndlessTrackSpawner Spawner { get; private set; }
        public AvalancheChaser Avalanche { get; private set; }

        public GameState State { get; private set; } = GameState.Lobby;

        public int MaxHearts { get; private set; } = 3;
        public int CurrentHearts { get; private set; } = 3;
        public float DistanceTraveled { get; private set; }
        public int CoinsCollected { get; private set; }
        public int GemsCollected { get; private set; }
        public int CurrentScore { get; private set; }

        public int TotalLoadedCoins { get; private set; }
        public int TotalLoadedGems { get; private set; }
        public int TotalLoadedDistance { get; private set; }
        public float AvalancheThreat { get; private set; } = 0f;

        private float _bannerTimer;
        private string _activeBannerMessage = "";
        private Vector3 _lastPlayerPos;

        private GameObject _lobbyPanel;
        private GameObject _hudPanel;
        private GameObject _gameOverPanel;

        private Text _lobbyStatsText;
        private Text _scoreText;
        private Text _heartsText;
        private Text _coinText;
        private Text _gemText;
        private Text _bannerText;
        private Text _gameOverSummaryText;

        private const string CoinSaveKey = "COINSAVE";
        private const string GemSaveKey = "GEMSAVE";
        private const string DistanceSaveKey = "DISTANCESAVE";

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        private static void AutoBootstrapIfNeeded()
        {
            PurgeBrokenAndStaleObjects();
            GameManager existing = SnowCompatibility.FindOne<GameManager>();
            if (existing == null)
            {
                GameObject root = new GameObject("SnowRunner3D_GameSystem");
                existing = root.AddComponent<GameManager>();
            }
            existing.BuildCompleteRuntimeScene();
            existing.OpenLobby();
        }

        public static void PurgeBrokenAndStaleObjects()
        {
#if UNITY_EDITOR
            GameObject[] allObjects = Resources.FindObjectsOfTypeAll<GameObject>();
            foreach (GameObject go in allObjects)
            {
                if (go != null && go.scene.isLoaded)
                {
                    int removed = GameObjectUtility.RemoveMonoBehavioursWithMissingScript(go);
                    if (removed > 0 && (
                        go.name.Contains("SnowRunner") ||
                        go.name.Contains("Player_Snowboarder") ||
                        go.name.Contains("EndlessTrackSpawner") ||
                        go.name.Contains("AvalancheChaserWall") ||
                        go.name.Contains("SnowEnvironmentController")))
                    {
                        DestroyImmediate(go);
                    }
                }
            }
#endif
            string[] staleNames = {
                "SnowRunner_UICanvas",
                "Player_Snowboarder",
                "EndlessTrackSpawner",
                "AvalancheChaserWall",
                "SnowEnvironmentController",
                "SnowyResortLogCabin"
            };
            foreach (string sName in staleNames)
            {
                GameObject found = GameObject.Find(sName);
                while (found != null)
                {
                    DestroyImmediate(found);
                    found = GameObject.Find(sName);
                }
            }
        }

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }
            Instance = this;
            LoadSaveData();
        }

        private void LoadSaveData()
        {
            TotalLoadedCoins = PlayerPrefs.GetInt(CoinSaveKey, 0);
            TotalLoadedGems = PlayerPrefs.GetInt(GemSaveKey, 0);
            TotalLoadedDistance = PlayerPrefs.GetInt(DistanceSaveKey, 0);
        }

        private void OnEnable()
        {
            Instance = this;
            LoadSaveData();
            if (Application.isPlaying && (Player == null || Spawner == null || _hudPanel == null))
            {
                BuildCompleteRuntimeScene();
                OpenLobby();
            }
        }

        private void Start()
        {
            BuildCompleteRuntimeScene();
            OpenLobby();
        }

        public void BuildCompleteRuntimeScene()
        {
            Instance = this;
            PurgeBrokenAndStaleObjects();

            Light dirLight = SnowCompatibility.FindOne<Light>();
            if (dirLight == null)
            {
                GameObject lightObj = new GameObject("AlpineDirectionalSun");
                dirLight = lightObj.AddComponent<Light>();
                dirLight.type = LightType.Directional;
                dirLight.shadows = LightShadows.Soft;
                lightObj.transform.rotation = Quaternion.Euler(42f, -32f, 0f);
            }

            Player = CreateCapstoneRunnerKid();
            Player.ResetPlayer();

            CreateSnowyLogCabinResort();

            Camera mainCam = Camera.main;
            if (mainCam == null)
            {
                GameObject camObj = new GameObject("Main Camera");
                camObj.tag = "MainCamera";
                mainCam = camObj.AddComponent<Camera>();
                camObj.AddComponent<AudioListener>();
            }
            SnowCameraFollow camFollow = mainCam.GetComponent<SnowCameraFollow>();
            if (camFollow == null) camFollow = mainCam.gameObject.AddComponent<SnowCameraFollow>();
            camFollow.target = Player.transform;

            GameObject spawnerObj = new GameObject("EndlessTrackSpawner");
            Spawner = spawnerObj.AddComponent<EndlessTrackSpawner>();
            Spawner.playerTransform = Player.transform;
            Spawner.EnsureInitialized();
            Spawner.ResetTrack();

            Avalanche = CreateAvalancheWall(Player.transform);

            GameObject envObj = new GameObject("SnowEnvironmentController");
            SnowEnvironmentController env = envObj.AddComponent<SnowEnvironmentController>();
            env.followTarget = Player.transform;
            env.directionalLight = dirLight;
            env.SetupAtmosphere();

            BuildUserInterface();
        }

        private PlayerSnowController CreateCapstoneRunnerKid()
        {
            GameObject playerObj = new GameObject("Player_Snowboarder");
            CharacterController cc = playerObj.AddComponent<CharacterController>();
            cc.height = 1.7f;
            cc.radius = 0.40f;
            cc.center = new Vector3(0f, 0.85f, 0f);

            PlayerSnowController ctrl = playerObj.AddComponent<PlayerSnowController>();

            GameObject visualRoot = new GameObject("VisualModel");
            visualRoot.transform.SetParent(playerObj.transform);
            visualRoot.transform.localPosition = Vector3.zero;
            ctrl.visualRoot = visualRoot.transform;

            Material redCoatMat = SnowCompatibility.CreateMaterial("RedParkaMat", new Color(0.88f, 0.15f, 0.22f), 0.35f, 0.0f);
            Material tealStripeMat = SnowCompatibility.CreateMaterial("TealStripeMat", new Color(0.0f, 0.75f, 0.65f), 0.40f, 0.0f);
            Material whiteFurMat = SnowCompatibility.CreateMaterial("FluffyWhiteFurMat", new Color(0.97f, 0.96f, 0.92f), 0.15f, 0.0f);
            Material navyPantsMat = SnowCompatibility.CreateMaterial("NavySnowPantsMat", new Color(0.12f, 0.15f, 0.24f), 0.25f, 0.0f);
            Material bootMat = SnowCompatibility.CreateMaterial("SnowBootMat", new Color(0.18f, 0.20f, 0.26f), 0.35f, 0.0f);
            Material skinMat = SnowCompatibility.CreateMaterial("KidSkinTone", new Color(1.0f, 0.88f, 0.78f), 0.25f, 0.0f);
            Material hairMat = SnowCompatibility.CreateMaterial("DarkHairMat", new Color(0.24f, 0.14f, 0.08f), 0.20f, 0.0f);
            Material eyeMat = SnowCompatibility.CreateMaterial("KidEyesMat", new Color(0.12f, 0.08f, 0.06f), 0.90f, 0.1f);

            // 1. Torso
            GameObject torso = GameObject.CreatePrimitive(PrimitiveType.Cube);
            DestroyImmediate(torso.GetComponent<Collider>());
            torso.name = "KidTorso";
            torso.transform.SetParent(visualRoot.transform);
            torso.transform.localPosition = new Vector3(0f, 0.88f, 0f);
            torso.transform.localScale = new Vector3(0.68f, 0.62f, 0.50f);
            torso.GetComponent<Renderer>().sharedMaterial = redCoatMat;
            ctrl.torsoRenderer = torso.GetComponent<Renderer>();

            GameObject tealPanel = GameObject.CreatePrimitive(PrimitiveType.Cube);
            DestroyImmediate(tealPanel.GetComponent<Collider>());
            tealPanel.name = "TealStripe";
            tealPanel.transform.SetParent(torso.transform);
            tealPanel.transform.localPosition = new Vector3(0f, 0.15f, 0.52f);
            tealPanel.transform.localScale = new Vector3(0.42f, 0.70f, 0.08f);
            tealPanel.GetComponent<Renderer>().sharedMaterial = tealStripeMat;
            ctrl.stripeRenderer = tealPanel.GetComponent<Renderer>();

            GameObject coatFurHem = GameObject.CreatePrimitive(PrimitiveType.Cube);
            DestroyImmediate(coatFurHem.GetComponent<Collider>());
            coatFurHem.transform.SetParent(torso.transform);
            coatFurHem.transform.localPosition = new Vector3(0f, -0.52f, 0f);
            coatFurHem.transform.localScale = new Vector3(1.10f, 0.18f, 1.10f);
            coatFurHem.GetComponent<Renderer>().sharedMaterial = whiteFurMat;
            ctrl.furTrimRenderers.Add(coatFurHem.GetComponent<Renderer>());

            // 2. Head with Fur-Lined Parka Hood
            GameObject head = GameObject.CreatePrimitive(PrimitiveType.Cube);
            DestroyImmediate(head.GetComponent<Collider>());
            head.name = "KidFace";
            head.transform.SetParent(visualRoot.transform);
            head.transform.localPosition = new Vector3(0f, 1.40f, 0.05f);
            head.transform.localScale = new Vector3(0.50f, 0.50f, 0.45f);
            head.GetComponent<Renderer>().sharedMaterial = skinMat;

            for (int eyeSide = -1; eyeSide <= 1; eyeSide += 2)
            {
                GameObject eye = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                DestroyImmediate(eye.GetComponent<Collider>());
                eye.transform.SetParent(head.transform);
                eye.transform.localPosition = new Vector3(eyeSide * 0.24f, 0.08f, 0.52f);
                eye.transform.localScale = new Vector3(0.12f, 0.18f, 0.08f);
                eye.GetComponent<Renderer>().sharedMaterial = eyeMat;
            }
            GameObject hairBangs = GameObject.CreatePrimitive(PrimitiveType.Cube);
            DestroyImmediate(hairBangs.GetComponent<Collider>());
            hairBangs.transform.SetParent(head.transform);
            hairBangs.transform.localPosition = new Vector3(0f, 0.38f, 0.42f);
            hairBangs.transform.localScale = new Vector3(0.65f, 0.22f, 0.25f);
            hairBangs.GetComponent<Renderer>().sharedMaterial = hairMat;

            GameObject hoodShell = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            DestroyImmediate(hoodShell.GetComponent<Collider>());
            hoodShell.name = "ParkaHoodShell";
            hoodShell.transform.SetParent(visualRoot.transform);
            hoodShell.transform.localPosition = new Vector3(0f, 1.44f, -0.05f);
            hoodShell.transform.localScale = new Vector3(0.82f, 0.82f, 0.82f);
            hoodShell.GetComponent<Renderer>().sharedMaterial = redCoatMat;
            ctrl.hoodRenderer = hoodShell.GetComponent<Renderer>();

            GameObject hoodFurRim = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            DestroyImmediate(hoodFurRim.GetComponent<Collider>());
            hoodFurRim.name = "FluffyFurHoodRim";
            hoodFurRim.transform.SetParent(visualRoot.transform);
            hoodFurRim.transform.localPosition = new Vector3(0f, 1.44f, 0.25f);
            hoodFurRim.transform.localRotation = Quaternion.Euler(90f, 0f, 0f);
            hoodFurRim.transform.localScale = new Vector3(0.88f, 0.08f, 0.88f);
            hoodFurRim.GetComponent<Renderer>().sharedMaterial = whiteFurMat;
            ctrl.furTrimRenderers.Add(hoodFurRim.GetComponent<Renderer>());

            // 3. Legs & Boots
            ctrl.pantsRenderers.Clear();
            ctrl.bootRenderers.Clear();
            for (int side = -1; side <= 1; side += 2)
            {
                GameObject legRoot = new GameObject(side == -1 ? "LeftLeg" : "RightLeg");
                legRoot.transform.SetParent(visualRoot.transform);
                legRoot.transform.localPosition = new Vector3(side * 0.18f, 0.52f, 0f);

                GameObject pants = GameObject.CreatePrimitive(PrimitiveType.Cube);
                DestroyImmediate(pants.GetComponent<Collider>());
                pants.transform.SetParent(legRoot.transform);
                pants.transform.localPosition = new Vector3(0f, -0.15f, 0f);
                pants.transform.localScale = new Vector3(0.22f, 0.32f, 0.24f);
                pants.GetComponent<Renderer>().sharedMaterial = navyPantsMat;
                ctrl.pantsRenderers.Add(pants.GetComponent<Renderer>());

                GameObject bootFur = GameObject.CreatePrimitive(PrimitiveType.Cube);
                DestroyImmediate(bootFur.GetComponent<Collider>());
                bootFur.transform.SetParent(legRoot.transform);
                bootFur.transform.localPosition = new Vector3(0f, -0.32f, 0f);
                bootFur.transform.localScale = new Vector3(0.28f, 0.08f, 0.32f);
                bootFur.GetComponent<Renderer>().sharedMaterial = whiteFurMat;
                ctrl.furTrimRenderers.Add(bootFur.GetComponent<Renderer>());

                GameObject boot = GameObject.CreatePrimitive(PrimitiveType.Cube);
                DestroyImmediate(boot.GetComponent<Collider>());
                boot.transform.SetParent(legRoot.transform);
                boot.transform.localPosition = new Vector3(0f, -0.44f, 0.06f);
                boot.transform.localScale = new Vector3(0.24f, 0.18f, 0.40f);
                boot.GetComponent<Renderer>().sharedMaterial = bootMat;
                ctrl.bootRenderers.Add(boot.GetComponent<Renderer>());
            }

            // 4. Arms & Mittens
            ctrl.sleeveRenderers.Clear();
            ctrl.mittenRenderers.Clear();
            for (int side = -1; side <= 1; side += 2)
            {
                GameObject armRoot = new GameObject(side == -1 ? "LeftArm" : "RightArm");
                armRoot.transform.SetParent(visualRoot.transform);
                armRoot.transform.localPosition = new Vector3(side * 0.42f, 1.05f, 0f);

                GameObject sleeve = GameObject.CreatePrimitive(PrimitiveType.Cube);
                DestroyImmediate(sleeve.GetComponent<Collider>());
                sleeve.transform.SetParent(armRoot.transform);
                sleeve.transform.localPosition = new Vector3(0f, -0.18f, 0f);
                sleeve.transform.localScale = new Vector3(0.20f, 0.36f, 0.20f);
                sleeve.GetComponent<Renderer>().sharedMaterial = redCoatMat;
                ctrl.sleeveRenderers.Add(sleeve.GetComponent<Renderer>());

                GameObject cuffFur = GameObject.CreatePrimitive(PrimitiveType.Cube);
                DestroyImmediate(cuffFur.GetComponent<Collider>());
                cuffFur.transform.SetParent(armRoot.transform);
                cuffFur.transform.localPosition = new Vector3(0f, -0.38f, 0f);
                cuffFur.transform.localScale = new Vector3(0.26f, 0.08f, 0.26f);
                cuffFur.GetComponent<Renderer>().sharedMaterial = whiteFurMat;
                ctrl.furTrimRenderers.Add(cuffFur.GetComponent<Renderer>());

                GameObject mitten = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                DestroyImmediate(mitten.GetComponent<Collider>());
                mitten.transform.SetParent(armRoot.transform);
                mitten.transform.localPosition = new Vector3(0f, -0.48f, 0.02f);
                mitten.transform.localScale = new Vector3(0.22f, 0.22f, 0.22f);
                mitten.GetComponent<Renderer>().sharedMaterial = navyPantsMat;
                ctrl.mittenRenderers.Add(mitten.GetComponent<Renderer>());
            }

            // 5. Snow Footsteps Particle Emitter
            GameObject stepPsObj = new GameObject("SnowFootstepsParticle");
            stepPsObj.transform.SetParent(playerObj.transform);
            stepPsObj.transform.localPosition = new Vector3(0f, 0.05f, -0.3f);
            ParticleSystem stepPs = stepPsObj.AddComponent<ParticleSystem>();
            var main = stepPs.main;
            main.startLifetime = 0.35f;
            main.startSpeed = new ParticleSystem.MinMaxCurve(1.5f, 3.5f);
            main.startSize = new ParticleSystem.MinMaxCurve(0.08f, 0.20f);
            main.maxParticles = 120;
            main.simulationSpace = ParticleSystemSimulationSpace.World;
            var emission = stepPs.emission;
            emission.rateOverTime = 38f;
            var shape = stepPs.shape;
            shape.shapeType = ParticleSystemShapeType.Circle;
            shape.radius = 0.35f;
            ParticleSystemRenderer psRend = stepPsObj.GetComponent<ParticleSystemRenderer>();
            Shader pShader = Shader.Find("Particles/Standard Unlit");
            if (pShader == null) pShader = SnowCompatibility.GetLitShader();
            Material stepMat = new Material(pShader);
            stepMat.color = new Color(0.95f, 0.98f, 1f);
            psRend.sharedMaterial = stepMat;
            ctrl.snowStepParticles = stepPs;

            // Shield & Magnet Auras
            GameObject shieldSphere = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            DestroyImmediate(shieldSphere.GetComponent<Collider>());
            shieldSphere.name = "ShieldAura";
            shieldSphere.transform.SetParent(playerObj.transform);
            shieldSphere.transform.localPosition = new Vector3(0f, 0.85f, 0f);
            shieldSphere.transform.localScale = new Vector3(2.1f, 2.1f, 2.1f);
            shieldSphere.GetComponent<Renderer>().sharedMaterial = SnowCompatibility.CreateMaterial("ShieldBubble", new Color(0.2f, 0.85f, 1f), 0.9f, 0.2f, new Color(0.15f, 0.5f, 0.7f));
            shieldSphere.SetActive(false);
            ctrl.shieldVisual = shieldSphere;

            GameObject magnetRing = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            DestroyImmediate(magnetRing.GetComponent<Collider>());
            magnetRing.name = "MagnetAura";
            magnetRing.transform.SetParent(playerObj.transform);
            magnetRing.transform.localPosition = new Vector3(0f, 0.12f, 0f);
            magnetRing.transform.localScale = new Vector3(2.2f, 0.04f, 2.2f);
            magnetRing.GetComponent<Renderer>().sharedMaterial = SnowCompatibility.CreateMaterial("MagnetAuraMat", new Color(1f, 0.2f, 0.65f), 0.85f, 0.2f, new Color(0.5f, 0.05f, 0.25f));
            magnetRing.SetActive(false);
            ctrl.magnetVisual = magnetRing;

            return ctrl;
        }

        private void CreateSnowyLogCabinResort()
        {
            GameObject cabin = new GameObject("SnowyResortLogCabin");
            cabin.transform.position = new Vector3(-6.5f, 0f, 6.5f);
            cabin.transform.rotation = Quaternion.Euler(0f, 32f, 0f);

            Material woodMat = SnowCompatibility.CreateMaterial("CabinLogWood", new Color(0.48f, 0.32f, 0.18f), 0.2f, 0f);
            Material roofSnowMat = SnowCompatibility.CreateMaterial("CabinRoofSnow", new Color(0.96f, 0.98f, 1f), 0.3f, 0f);
            Material warmWindowMat = SnowCompatibility.CreateMaterial("WarmGlowWindow", new Color(1.0f, 0.72f, 0.15f), 0.9f, 0f, new Color(1.0f, 0.65f, 0.1f));
            Material chimneyStoneMat = SnowCompatibility.CreateMaterial("ChimneyStone", new Color(0.35f, 0.36f, 0.38f), 0.15f, 0f);

            GameObject body = GameObject.CreatePrimitive(PrimitiveType.Cube);
            DestroyImmediate(body.GetComponent<Collider>());
            body.transform.SetParent(cabin.transform);
            body.transform.localPosition = new Vector3(0f, 1.6f, 0f);
            body.transform.localScale = new Vector3(4.8f, 3.2f, 4.2f);
            body.GetComponent<Renderer>().sharedMaterial = woodMat;

            GameObject roof = GameObject.CreatePrimitive(PrimitiveType.Cube);
            DestroyImmediate(roof.GetComponent<Collider>());
            roof.transform.SetParent(cabin.transform);
            roof.transform.localPosition = new Vector3(0f, 3.6f, 0f);
            roof.transform.localRotation = Quaternion.Euler(0f, 0f, 22f);
            roof.transform.localScale = new Vector3(3.5f, 0.6f, 4.8f);
            roof.GetComponent<Renderer>().sharedMaterial = roofSnowMat;

            GameObject roof2 = GameObject.CreatePrimitive(PrimitiveType.Cube);
            DestroyImmediate(roof2.GetComponent<Collider>());
            roof2.transform.SetParent(cabin.transform);
            roof2.transform.localPosition = new Vector3(0f, 3.6f, 0f);
            roof2.transform.localRotation = Quaternion.Euler(0f, 0f, -22f);
            roof2.transform.localScale = new Vector3(3.5f, 0.6f, 4.8f);
            roof2.GetComponent<Renderer>().sharedMaterial = roofSnowMat;

            GameObject chimney = GameObject.CreatePrimitive(PrimitiveType.Cube);
            DestroyImmediate(chimney.GetComponent<Collider>());
            chimney.transform.SetParent(cabin.transform);
            chimney.transform.localPosition = new Vector3(-1.4f, 4.6f, 0.8f);
            chimney.transform.localScale = new Vector3(0.75f, 2.2f, 0.75f);
            chimney.GetComponent<Renderer>().sharedMaterial = chimneyStoneMat;

            GameObject win = GameObject.CreatePrimitive(PrimitiveType.Cube);
            DestroyImmediate(win.GetComponent<Collider>());
            win.transform.SetParent(cabin.transform);
            win.transform.localPosition = new Vector3(0.9f, 1.6f, 2.12f);
            win.transform.localScale = new Vector3(0.85f, 0.85f, 0.08f);
            win.GetComponent<Renderer>().sharedMaterial = warmWindowMat;

            for (float fz = -2f; fz <= 4f; fz += 2f)
            {
                GameObject post = GameObject.CreatePrimitive(PrimitiveType.Cube);
                DestroyImmediate(post.GetComponent<Collider>());
                post.transform.SetParent(cabin.transform);
                post.transform.localPosition = new Vector3(3.0f, 0.5f, fz);
                post.transform.localScale = new Vector3(0.18f, 1.0f, 0.18f);
                post.GetComponent<Renderer>().sharedMaterial = woodMat;
            }
        }

        private AvalancheChaser CreateAvalancheWall(Transform playerTarget)
        {
            GameObject avObj = new GameObject("AvalancheChaserWall");
            avObj.transform.position = new Vector3(0f, 0f, -12f);
            AvalancheChaser chaser = avObj.AddComponent<AvalancheChaser>();
            chaser.playerTarget = playerTarget;

            Material snowCloudMat = SnowCompatibility.CreateMaterial("AvalancheSnow", new Color(0.94f, 0.97f, 1.0f), 0.15f, 0f);
            for (int i = -3; i <= 3; i++)
            {
                GameObject billow = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                DestroyImmediate(billow.GetComponent<Collider>());
                billow.transform.SetParent(avObj.transform);
                billow.transform.localPosition = new Vector3(i * 2.1f, 1.8f + Mathf.Abs(i % 2) * 0.6f, 0f);
                billow.transform.localScale = new Vector3(3.8f, 3.6f, 2.8f);
                billow.GetComponent<Renderer>().sharedMaterial = snowCloudMat;
            }
            return chaser;
        }

        public void OpenLobby()
        {
            State = GameState.Lobby;
            Time.timeScale = 1f;
            LoadSaveData();

            if (Player != null) Player.ResetPlayer();
            if (Spawner != null) Spawner.ResetTrack();

            if (_lobbyPanel != null) _lobbyPanel.SetActive(true);
            if (_hudPanel != null) _hudPanel.SetActive(false);
            if (_gameOverPanel != null) _gameOverPanel.SetActive(false);

            if (_lobbyStatsText != null)
            {
                _lobbyStatsText.text =
                    $"🏆 MAX DISTANCE: {TotalLoadedDistance:N0} m   |   🪙 TOTAL COINS: {TotalLoadedCoins:N0}   |   💎 GEMS: {TotalLoadedGems:N0}";
            }
        }

        public void StartGame()
        {
            if (Player == null || Spawner == null || _hudPanel == null)
            {
                BuildCompleteRuntimeScene();
            }

            CurrentHearts = MaxHearts;
            DistanceTraveled = 0f;
            CoinsCollected = 0;
            GemsCollected = 0;
            CurrentScore = 0;
            _bannerTimer = 3.0f;
            _activeBannerMessage = "RUN! [A/D] MOVE  |  [W/SPACE] JUMP LOGS  |  [S] SLIDE  |  [1-4] DRESS!";
            AvalancheThreat = 0f;

            if (Player != null)
            {
                Player.ResetPlayer();
                _lastPlayerPos = Player.transform.position;
            }
            if (Spawner != null)
            {
                Spawner.ResetTrack();
            }

            State = GameState.Playing;
            Time.timeScale = 1f;

            if (_lobbyPanel != null) _lobbyPanel.SetActive(false);
            if (_gameOverPanel != null) _gameOverPanel.SetActive(false);
            if (_hudPanel != null) _hudPanel.SetActive(true);

#if UNITY_EDITOR
            System.Type gvType = System.Type.GetType("UnityEditor.GameView,UnityEditor");
            if (gvType != null) EditorWindow.FocusWindowIfItsOpen(gvType);
#endif
        }

        public void QuitGame()
        {
            Time.timeScale = 1f;
#if UNITY_EDITOR
            EditorApplication.isPlaying = false;
#else
            Application.Quit();
#endif
        }

        public void TogglePause()
        {
            if (State == GameState.Playing)
            {
                State = GameState.Paused;
                Time.timeScale = 0f;
                ShowFloatingBanner("GAME PAUSED (PRESS P TO RESUME)");
            }
            else if (State == GameState.Paused)
            {
                State = GameState.Playing;
                Time.timeScale = 1f;
            }
        }

        public void ShowFloatingBanner(string message)
        {
            _activeBannerMessage = message;
            _bannerTimer = 2.0f;
        }

        public void AddCoins(int count, int score)
        {
            CoinsCollected += count;
            CurrentScore += score;
        }

        public void AddGems(int count, int score)
        {
            GemsCollected += count;
            CurrentScore += score;
            ShowFloatingBanner($"+{count} BLUE GEM (+{score} SCORE)!");
        }

        public void HealPlayer(int amount)
        {
            CurrentHearts = Mathf.Min(MaxHearts, CurrentHearts + amount);
        }

        public void TakePlayerDamage(int damage)
        {
            CurrentHearts -= damage;

            if (CurrentHearts <= 0)
            {
                CurrentHearts = 0;
                TriggerGameOver();
            }
            else
            {
                ShowFloatingBanner($"COLLISION! {CurrentHearts} {(CurrentHearts == 1 ? "HEART" : "HEARTS")} LEFT!");
            }
        }

        public void RegisterStumble()
        {
            AvalancheThreat += 0.5f;
            ShowFloatingBanner("SNOWDRIFT STUMBLE! AVALANCHE CLOSING IN!");
            if (AvalancheThreat >= 1.0f)
            {
                TakePlayerDamage(1);
                AvalancheThreat = 0.35f;
            }
        }

        public void TriggerGameOver()
        {
            if (State != GameState.Playing) return;
            State = GameState.GameOver;

            int finalDist = Mathf.FloorToInt(DistanceTraveled);
            TotalLoadedCoins += CoinsCollected;
            TotalLoadedGems += GemsCollected;
            if (finalDist > TotalLoadedDistance)
            {
                TotalLoadedDistance = finalDist;
            }
            PlayerPrefs.SetInt(CoinSaveKey, TotalLoadedCoins);
            PlayerPrefs.SetInt(GemSaveKey, TotalLoadedGems);
            PlayerPrefs.SetInt(DistanceSaveKey, TotalLoadedDistance);
            PlayerPrefs.Save();

            if (_hudPanel != null) _hudPanel.SetActive(false);
            if (_lobbyPanel != null) _lobbyPanel.SetActive(false);
            if (_gameOverPanel != null) _gameOverPanel.SetActive(true);
            if (_gameOverSummaryText != null)
            {
                _gameOverSummaryText.text =
                    $"DISTANCE RUN: {finalDist:N0} m   (BEST: {TotalLoadedDistance:N0} m)\n\n" +
                    $"Coins: {CoinsCollected}   |   Blue Gems: {GemsCollected}   |   Score: {CurrentScore:N0}\n\n" +
                    $"Choose an action (or press [R] to Restart, [L] for Lobby, [ESC] to Quit):";
            }
        }

        private void OnGUI()
        {
            Event e = Event.current;
            if (e != null && e.type == EventType.KeyDown)
            {
                if (State == GameState.Lobby)
                {
                    if (e.keyCode == KeyCode.Space || e.keyCode == KeyCode.Return)
                    {
                        StartGame();
                        return;
                    }
                    else if (e.keyCode == KeyCode.Escape)
                    {
                        QuitGame();
                        return;
                    }
                }
                else if (State == GameState.GameOver)
                {
                    if (e.keyCode == KeyCode.R || e.keyCode == KeyCode.Space || e.keyCode == KeyCode.Return)
                    {
                        StartGame();
                        return;
                    }
                    else if (e.keyCode == KeyCode.L)
                    {
                        OpenLobby();
                        return;
                    }
                    else if (e.keyCode == KeyCode.Escape)
                    {
                        QuitGame();
                        return;
                    }
                }
                else if (e.keyCode == KeyCode.P)
                {
                    TogglePause();
                }
            }

            if (State == GameState.GameOver)
            {
                GUIStyle btnStyle = new GUIStyle(GUI.skin.button);
                btnStyle.fontSize = 18;
                btnStyle.fontStyle = FontStyle.Bold;
                btnStyle.normal.textColor = Color.white;
                btnStyle.hover.textColor = Color.yellow;

                float centerX = Screen.width * 0.5f;
                float btnY = Screen.height * 0.5f + 70f;

                GUI.backgroundColor = new Color(0.12f, 0.82f, 0.35f, 1f);
                if (GUI.Button(new Rect(centerX - 310f, btnY, 195f, 54f), "▶ RESTART (R)", btnStyle))
                {
                    StartGame();
                }

                GUI.backgroundColor = new Color(0.15f, 0.55f, 0.95f, 1f);
                if (GUI.Button(new Rect(centerX - 100f, btnY, 200f, 54f), "🏠 LOBBY (L)", btnStyle))
                {
                    OpenLobby();
                }

                GUI.backgroundColor = new Color(0.92f, 0.20f, 0.22f, 1f);
                if (GUI.Button(new Rect(centerX + 115f, btnY, 195f, 54f), "✖ QUIT (ESC)", btnStyle))
                {
                    QuitGame();
                }
            }
        }

        private void Update()
        {
            if (Player == null || Spawner == null || _hudPanel == null)
            {
                BuildCompleteRuntimeScene();
                OpenLobby();
                return;
            }

            if (State == GameState.Lobby)
            {
                if (SnowCompatibility.GetKeyDownSafe(KeyCode.Space, "spaceKey")
                    || SnowCompatibility.GetKeyDownSafe(KeyCode.Return, "enterKey"))
                {
                    StartGame();
                }
                return;
            }

            if (State == GameState.GameOver)
            {
                if (SnowCompatibility.GetKeyDownSafe(KeyCode.R, "rKey")
                    || SnowCompatibility.GetKeyDownSafe(KeyCode.Space, "spaceKey")
                    || SnowCompatibility.GetKeyDownSafe(KeyCode.Return, "enterKey"))
                {
                    StartGame();
                }
                else if (SnowCompatibility.GetKeyDownSafe(KeyCode.L, "lKey"))
                {
                    OpenLobby();
                }
                else if (SnowCompatibility.GetKeyDownSafe(KeyCode.Escape, "escapeKey"))
                {
                    QuitGame();
                }
                return;
            }

            if (SnowCompatibility.GetKeyDownSafe(KeyCode.P, "pKey"))
            {
                TogglePause();
            }

            if (State != GameState.Playing || Player == null) return;

            float frameDist = Mathf.Max(0f, Player.transform.position.z - _lastPlayerPos.z);
            DistanceTraveled += frameDist;
            _lastPlayerPos = Player.transform.position;

            if (_bannerTimer > 0f)
            {
                _bannerTimer -= Time.deltaTime;
            }

            if (AvalancheThreat > 0f)
            {
                AvalancheThreat = Mathf.MoveTowards(AvalancheThreat, 0f, 0.12f * Time.deltaTime);
            }

            UpdateHudText();
        }

        private void UpdateHudText()
        {
            if (_scoreText != null)
                _scoreText.text = $"DISTANCE: {DistanceTraveled:F0} M";

            if (_heartsText != null)
            {
                string hearts = "";
                for (int i = 0; i < MaxHearts; i++)
                    hearts += (i < CurrentHearts) ? "♥ " : "♡ ";
                _heartsText.text = $"LIVES: {hearts}";
            }

            if (_coinText != null)
                _coinText.text = $"COINS: {CoinsCollected}";

            if (_gemText != null)
                _gemText.text = $"GEMS: {GemsCollected}";

            if (_bannerText != null)
            {
                if (_bannerTimer > 0f)
                {
                    _bannerText.text = _activeBannerMessage;
                }
                else
                {
                    string status = "";
                    if (Player.HasShield) status += $"[SHIELD: {Player.ShieldRemaining:F1}s]  ";
                    if (Player.HasMagnet) status += $"[MAGNET: {Player.MagnetRemaining:F1}s]  ";
                    _bannerText.text = status;
                }
            }
        }

        private void BuildUserInterface()
        {
            EventSystem existingEs = SnowCompatibility.FindOne<EventSystem>();
            GameObject esObj = existingEs != null ? existingEs.gameObject : new GameObject("EventSystem");
            SnowCompatibility.SetupCompatibleEventSystem(esObj);

            GameObject canvasObj = new GameObject("SnowRunner_UICanvas");
            Canvas canvas = canvasObj.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            CanvasScaler scaler = canvasObj.AddComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1280, 720);
            scaler.matchWidthOrHeight = 0.5f;
            canvasObj.AddComponent<GraphicRaycaster>();

            Font font = SnowCompatibility.GetDefaultFont();

            // ==========================================
            // 1. LOBBY PANEL (With Dress Customizer!)
            // ==========================================
            _lobbyPanel = CreatePanel(canvasObj.transform, "Lobby_Panel", new Color(0.05f, 0.09f, 0.18f, 0.70f));

            CreateText(_lobbyPanel.transform, "LobbyTitle", "3D ENDLESS RUNNER", font, 52, TextAnchor.MiddleCenter, new Vector2(0, 220), new Vector2(900, 70), Color.white);
            CreateText(_lobbyPanel.transform, "LobbySubtitle", "Snow Theme", font, 24, TextAnchor.MiddleCenter, new Vector2(0, 175), new Vector2(700, 35), new Color(0.35f, 0.88f, 1f));

            _lobbyStatsText = CreateText(_lobbyPanel.transform, "LobbyStats",
                $"🏆 MAX DISTANCE: {TotalLoadedDistance:N0} m   |   🪙 TOTAL COINS: {TotalLoadedCoins:N0}   |   💎 GEMS: {TotalLoadedGems:N0}",
                font, 19, TextAnchor.MiddleCenter, new Vector2(0, 130), new Vector2(950, 35), new Color(1f, 0.86f, 0.25f));

            // Dedicated Dress / Outfit Wardrobe Row in Lobby!
            CreateText(_lobbyPanel.transform, "DressHeader", "--- 🧥 CHANGE DRESS / OUTFIT (CLICK OR PRESS 1, 2, 3, 4) ---", font, 18, TextAnchor.MiddleCenter, new Vector2(0, -95), new Vector2(850, 35), new Color(1f, 0.88f, 0.35f));
            CreateButton(_lobbyPanel.transform, "Dress1", "[1] CLASSIC RED", font, new Vector2(-330, -145), new Vector2(205, 46), new Color(0.88f, 0.15f, 0.22f, 0.95f), () => Player?.ActivateOutfit(0));
            CreateButton(_lobbyPanel.transform, "Dress2", "[2] GLACIER CYAN", font, new Vector2(-110, -145), new Vector2(205, 46), new Color(0.08f, 0.70f, 0.94f, 0.95f), () => Player?.ActivateOutfit(1));
            CreateButton(_lobbyPanel.transform, "Dress3", "[3] PINE RANGER", font, new Vector2(110, -145), new Vector2(205, 46), new Color(0.09f, 0.47f, 0.27f, 0.95f), () => Player?.ActivateOutfit(2));
            CreateButton(_lobbyPanel.transform, "Dress4", "[4] AURORA PINK", font, new Vector2(330, -145), new Vector2(205, 46), new Color(1.0f, 0.16f, 0.43f, 0.95f), () => Player?.ActivateOutfit(3));

            CreateButton(_lobbyPanel.transform, "StartRunBtn", "▶ START GAME (SPACE / ENTER)", font, new Vector2(-140, -235), new Vector2(370, 60), new Color(0.12f, 0.82f, 0.35f, 0.98f), StartGame);
            CreateButton(_lobbyPanel.transform, "QuitGameBtn", "✖ QUIT GAME (ESC)", font, new Vector2(210, -235), new Vector2(220, 60), new Color(0.90f, 0.22f, 0.25f, 0.95f), QuitGame);

            // ==========================================
            // 2. HUD PANEL
            // ==========================================
            _hudPanel = CreatePanel(canvasObj.transform, "HUD_Panel", new Color(0, 0, 0, 0));

            _heartsText = CreateText(_hudPanel.transform, "HeartsText", "LIVES: ♥ ♥ ♥", font, 26, TextAnchor.UpperCenter, new Vector2(0, -14), new Vector2(850, 40), new Color(1f, 0.32f, 0.38f));
            _scoreText = CreateText(_hudPanel.transform, "ScoreText", "DISTANCE: 0 M", font, 24, TextAnchor.UpperCenter, new Vector2(0, -48), new Vector2(900, 40), Color.white);
            _coinText = CreateText(_hudPanel.transform, "CoinText", "COINS: 0", font, 20, TextAnchor.UpperCenter, new Vector2(-120, -80), new Vector2(300, 35), new Color(1f, 0.86f, 0.22f));
            _gemText = CreateText(_hudPanel.transform, "GemText", "GEMS: 0", font, 20, TextAnchor.UpperCenter, new Vector2(120, -80), new Vector2(300, 35), new Color(0.25f, 0.85f, 1.0f));
            _bannerText = CreateText(_hudPanel.transform, "BannerText", "", font, 24, TextAnchor.UpperCenter, new Vector2(0, -118), new Vector2(950, 45), new Color(0.25f, 0.96f, 1f));

            CreateButton(_hudPanel.transform, "HudLobbyBtn", "🏠 LOBBY", font, new Vector2(-480, 310), new Vector2(120, 40), new Color(0.15f, 0.55f, 0.9f, 0.85f), OpenLobby);

            CreateButton(_hudPanel.transform, "BtnLeft", "< LEFT (A)", font, new Vector2(-255, -310), new Vector2(150, 52), new Color(0.12f, 0.55f, 0.9f, 0.9f), () => Player?.QueueMoveLeft());
            CreateButton(_hudPanel.transform, "BtnRight", "RIGHT (D) >", font, new Vector2(-85, -310), new Vector2(150, 52), new Color(0.12f, 0.55f, 0.9f, 0.9f), () => Player?.QueueMoveRight());
            CreateButton(_hudPanel.transform, "BtnJump", "^ JUMP (SPACE)", font, new Vector2(85, -310), new Vector2(165, 52), new Color(0.12f, 0.65f, 0.35f, 0.9f), () => Player?.QueueJump());
            CreateButton(_hudPanel.transform, "BtnSlide", "v SLIDE (S)", font, new Vector2(255, -310), new Vector2(150, 52), new Color(0.92f, 0.45f, 0.15f, 0.9f), () => Player?.QueueSlide());

            // ==========================================
            // 3. GAME OVER PANEL
            // ==========================================
            _gameOverPanel = CreatePanel(canvasObj.transform, "GameOver_Panel", new Color(0.06f, 0.10f, 0.20f, 0.92f));
            CreateText(_gameOverPanel.transform, "GameOverTitle", "STUMBLE! OUT OF HEARTS", font, 44, TextAnchor.MiddleCenter, new Vector2(0, 130), new Vector2(850, 75), new Color(1f, 0.38f, 0.32f));
            _gameOverSummaryText = CreateText(_gameOverPanel.transform, "SummaryText", "", font, 24, TextAnchor.MiddleCenter, new Vector2(0, 20), new Vector2(900, 150), Color.white);

            _lobbyPanel.SetActive(true);
            _hudPanel.SetActive(false);
            _gameOverPanel.SetActive(false);
        }

        private GameObject CreatePanel(Transform parent, string name, Color bgColor)
        {
            GameObject panel = new GameObject(name);
            panel.transform.SetParent(parent, false);
            RectTransform rt = panel.AddComponent<RectTransform>();
            rt.anchorMin = Vector2.zero;
            rt.anchorMax = Vector2.one;
            rt.offsetMin = Vector2.zero;
            rt.offsetMax = Vector2.zero;

            Image img = panel.AddComponent<Image>();
            img.color = bgColor;
            return panel;
        }

        private Text CreateText(Transform parent, string name, string content, Font font, int fontSize, TextAnchor anchor, Vector2 anchoredPos, Vector2 size, Color color)
        {
            GameObject txtObj = new GameObject(name);
            txtObj.transform.SetParent(parent, false);
            RectTransform rt = txtObj.AddComponent<RectTransform>();

            if (anchor == TextAnchor.UpperCenter) { rt.anchorMin = new Vector2(0.5f, 1); rt.anchorMax = new Vector2(0.5f, 1); rt.pivot = new Vector2(0.5f, 1); }
            else { rt.anchorMin = new Vector2(0.5f, 0.5f); rt.anchorMax = new Vector2(0.5f, 0.5f); rt.pivot = new Vector2(0.5f, 0.5f); }

            rt.anchoredPosition = anchoredPos;
            rt.sizeDelta = size;

            Text txt = txtObj.AddComponent<Text>();
            txt.font = font;
            txt.text = content;
            txt.fontSize = fontSize;
            txt.alignment = anchor;
            txt.color = color;

            Shadow shadow = txtObj.AddComponent<Shadow>();
            shadow.effectColor = new Color(0, 0, 0, 0.85f);
            shadow.effectDistance = new Vector2(2, -2);
            return txt;
        }

        private void CreateButton(Transform parent, string name, string label, Font font, Vector2 pos, Vector2 size, Color btnColor, UnityEngine.Events.UnityAction onClick)
        {
            GameObject btnObj = new GameObject(name);
            btnObj.transform.SetParent(parent, false);
            RectTransform rt = btnObj.AddComponent<RectTransform>();
            rt.anchorMin = new Vector2(0.5f, 0.5f);
            rt.anchorMax = new Vector2(0.5f, 0.5f);
            rt.pivot = new Vector2(0.5f, 0.5f);
            rt.anchoredPosition = pos;
            rt.sizeDelta = size;

            Image img = btnObj.AddComponent<Image>();
            img.color = btnColor;

            Button btn = btnObj.AddComponent<Button>();
            btn.targetGraphic = img;
            btn.onClick.AddListener(onClick);

            CreateText(btnObj.transform, "Label", label, font, 14, TextAnchor.MiddleCenter, Vector2.zero, size, Color.white);
        }
    }
}
